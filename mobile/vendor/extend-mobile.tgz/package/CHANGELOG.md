# 更新日志

## 0.9.4 — 2026-10-24

- 插件投稿改成左右分栏：左边是你的投稿，右边看版本、商店信息和历史。上传 ZIP 后先由云端检查并列出读到的版本、图标和说明，确认后再提交；GitHub / npm 来源可以检查上游新版本并申请更新；只改商店信息不用重新上传包。版本号一律从包里或上游读取，不用手填。
- 新增「我的网页」：列出发布到 Forsion Connect 的网页，可打开、复制链接、下架，也可以申请上架商店、撤回或在被拒后重新申请。
- 蓬洲云同步页改成按类别开关：笔记、Agents 与记忆、我的资料、插件各一行，每行可选同步到所有设备、只在这台电脑或只和某台设备同步；改动先预览再确认，规则表移到「更多 › 高级」。侧栏、概览与各内容页同步整理，文件夹显示合计大小。
- 蓬洲云换上新的「祥云」图标与页头字标。

- Plugin submissions now use a split view: your submissions on the left; version, store details and history on the right. A ZIP is checked by the cloud first, showing the version, icon and notes it found, before you submit it; GitHub and npm items can check upstream for a new version and request an update; editing store details no longer needs a new package. Versions always come from the package or upstream, never typed in.
- New My web pages: lists the pages you published to Forsion Connect, with open, copy link and take down, plus applying for a store listing, withdrawing, or reapplying after a rejection.
- The Penzor Cloud sync page is now a list of categories: Notes, Agents & memory, About me and Plugins each have a switch and a choice of all devices, this computer only, or one other device. Changes are previewed before you confirm, and the rule table moves to More › Advanced. The sidebar, overview and content pages are reorganized to match, and folders show their total size.
- Penzor Cloud has a new ruyi-cloud icon and page-header wordmark.

## 0.9.3 — 2026-10-22

- 原生手机复用账号、个人主页、会员与积分商店、公告和蓬洲云，直接读取当前账号已有的云端资料。手机上传交文件选择器，下载通过宿主保存，付款与外部链接沿用系统浏览器；本机同步开关和诊断仅在桌面提供。需要带 `mobileHostApi: 1` 接缝的手机宿主。
- Web 与手机登出或切换账号后，立即取消旧传输并清除队列与文件夹缓存；延迟返回的资料、上传额度与登录交接不再影响新账号。
- 桌面同步支持按文件夹选择范围、方向与默认或设备专属云端位置；启用和修改规则前先预览，传输中可查看进度、暂停和重试。重命名保留同步身份，冲突保留待处理版本；旧桌面仍使用原有同步页。

- Native mobile now reuses the account/profile pages, membership and points store, announcements, and Penzor Cloud with the signed-in account’s existing cloud data. Uploads use the file picker, downloads are saved by the host, and payments/external links use the system browser. Local sync controls and diagnostics remain desktop-only. Requires a mobile host supporting `mobileHostApi: 1`.
- Signing out or switching accounts on Web/mobile cancels old transfers and clears the queue and folder cache. Late account responses, upload quota checks and browser handoffs cannot affect the new account.
- Desktop sync supports per-folder scope, direction and default or device-specific cloud destinations. Preview changes before enabling or editing rules, and follow, pause or retry transfers. Renames retain sync identity and unresolved versions stay available; older desktop hosts keep the original sync page.

## 0.9.2 — 2026-10-21

- 「我的云盘」统一按来源显示笔记库、Agents、我的资料、应用、插件数据和上传文件。同步与应用维护的内容只读，上传文件仍可整理。
- 统一用量包含现存文件与回收站，历史版本单列；通知与宽限状态由云端返回。云端尚未升级时保留原有文件访问，用量未知不会显示成零。
- Agents 与插件数据的同步页补充上次同步、失败、冲突副本与待上传状态；额度不足不再误报成单个文件过大。需要 Forsion Desktop 2.13.5 或更新，新增同步反馈随宿主能力显示。

- My drive groups cloud content by source: note vaults, Agents, your profile, apps, plugin data and uploaded files. Content maintained by sync or apps is read-only; uploaded files remain editable.
- Unified usage includes current files and trash, with history shown separately. Notices and grace periods follow the server response. Existing file access remains available before the server upgrade, and unknown usage is never shown as zero.
- Sync now shows the last run, failures, conflict copies and pending plugin changes when supported by the host. Storage quota errors no longer appear as a single-file size limit. Requires Forsion Desktop 2.13.5 or later.

## 0.9.1 — 2026-10-20

- **网页版也有了**：在服务器的网页版 Forsion（Unit 的网页主入口）里登录后，设置里的「Forsion 云端」有账号、个人主页、安全、额度与积分、用量记录、背包、插件投稿和反馈这几页，商店里有会员、积分、物品三页和投稿，公告照常弹。网页版装不了插件，所以商店里不列插件目录。买会员、充积分、打开个人中心会在浏览器新标签页里打开，不用再登录一次。
- 「蓬洲云」在网页版上也能用：概览、各本账、我的云盘和回收站都在，能重命名、移动、移到回收站、恢复、永久删除、新建文件夹，也能上传和下载。上传可以点「上传」选文件或整个文件夹，也能直接拖进文件表；下载会存进浏览器的下载，多选下载不另建文件夹。同样是各自同时 3 个、能暂停、继续、取消、重试，单个文件最大 50 MB、空间不够整批不开始。网页上的上传看不到进度，传完一下到头；关掉或刷新页面时还有没传完的，浏览器会先问一次。导出和智库同步的文件如果浏览器读不到，会在新标签页里打开，浏览器拦了弹出窗口就允许后再试一次。诊断上传只在桌面端。
- 看别的设备的设备页上照旧不出现这些页（那边登录的不是你这个账号）；网页版不跑笔记同步。
- 需要带同一批接缝的网页版 Forsion；更早的网页版上什么都不变。
- 修复：把文件夹拖进「我的云盘」、还没展开完就切到别的文件夹时，文件不再传进后来那个；刚点暂停或取消的下载不会再接着开始。

- **Now on the web too**: after you sign in to Forsion on the web (a server Unit’s main web page), Forsion Cloud in Settings has your account, profile, security, quota & points, usage, backpack, submissions and feedback, the store has the Membership, Points and Items pages plus submissions, and announcements show up as usual. The web version can’t install plugins, so the store doesn’t list them there. Buying membership, topping up points and opening the account center open in a new browser tab, already signed in.
- Penzor Cloud works on the web too: the overview, every ledger, My drive and Trash are there, and you can rename, move, move to trash, restore, delete permanently, create folders, upload and download. Upload files or a whole folder with Upload, or drag them into the file table; downloads go to your browser’s downloads, and a multi-file download doesn’t make a folder. Transfers work as on the desktop: 3 at a time each way, with pause, resume, cancel and retry, a 50 MB limit per file, and a batch that doesn’t fit your space doesn’t start. Uploads on the web don’t show progress and jump to done when finished. If you close or refresh the page while something is still transferring, the browser asks first. If the browser can’t read an export or a synced file directly, it opens in a new tab; if pop-ups are blocked, allow them and try again. Diagnostics upload is still desktop-only.
- Device pages, where you view another device, still don’t show these pages (that device isn’t signed in as you), and the web version doesn’t run note sync.
- Needs a web version of Forsion with the matching hooks; older web versions are unchanged.
- Fixed: dropping a folder into My drive and switching folders before it finished expanding no longer uploads into the folder you switched to, and a download you just paused or cancelled no longer starts anyway.

## 0.9.0 — 2026-10-20

- 这一版需要 Forsion 桌面端 2.13.5 或更新；更早的桌面端继续用自带的版本，升级桌面端后再换上。
- This version needs Forsion Desktop 2.13.5 or later. Older desktops keep the version they came with and switch after the desktop is updated.

- 新增 **「蓬洲云」Space**：在桌面端看和管理你存在 Forsion 云端的东西。打开先是概览：一共存了多少、按账分段的条、四张账卡（智库同步、Amadeus Cloud、应用文件、导出；有上限的两本各画各的条，用到 90% 变警示色）和占用最多的文件。左栏是位置树，点任一个库、应用、导出或回收站，主区换成文件表、右栏出详情。
- 能做的事按账分：应用文件可以下载、重命名、移动、移到回收站、恢复、永久删除、恢复历史版本；导出可以下载、重命名、删除；智库同步的库和 Amadeus Cloud 只看和下载（在这里删一个同步库的文件，每台设备都会跟着删）。下载存进「下载」文件夹。远程同步写入时带上设备名，蓬洲云里同步库的文件能看到是哪台写的。
- 左栏第一行是 **「同步」**：智库、Agents 与记忆、插件数据三项同步的开关、状态和在同步的设备都在这一页；展开智库那一行能看同步计划、方向、没传的文件和云端位置。另一台电脑登录、云端已经有一份智库时，就在这里选「合并两边」「用云端那份」（先就地确认一次，这台不一样的文件会先挪进旁边的备份文件夹）或「这台先不同步智库」；超出额度也在这里说清楚，放不下的文件留在本机，不删。
- 没开同步或有事等你决定时，打开蓬洲云先落在同步页；有事等你决定或上次没同步成功时，Ribbon 上的蓬洲云图标挂一个点；智库在同步或有文件在传时，图标挂进度环（传文件时以传文件为准）。
- 蓬洲云也能当网盘用：左栏有 **「我的云盘」**，工具条有「上传」（下拉里还能上传整个文件夹，云端照原样建好一层层）和「新建文件夹」，文件也能从访达直接拖进文件表，拖到某个文件夹那一行上就传进那个文件夹。我的云盘算在应用文件的 10 GB 里，重名自动改成「名字 (1)」，单个文件这一版最大 50 MB；空间不够时整批不开始，告诉你还差多少。
- 上传和下载都在后台排队（各自同时 3 个），切到别的 Space 也不停。正在传进当前文件夹的文件直接出现在表里、带进度；所有传输汇总在主区右下角的一张浮动卡里：每一项的进度、速度、剩余时间，能暂停、继续、取消、重试，下载完能「在文件夹中显示」。不碰它 10 秒收成一颗胶囊，全部传完 4 秒后自己消失，有没传完的一直留着。不在蓬洲云时传完或失败会弹一句。退出 Forsion 时还有在传的会问一次。暂停后继续、失败重试都是从头传。
- 多选：⌘ 点加选、⇧ 点连选、⌘A 全选，工具条换成批量条。应用文件里能批量下载、移动、移到回收站；智库同步的库和 Amadeus Cloud 里能批量下载。一次下载多个文件会放进「下载」里的「蓬洲云 日期」文件夹。
- 需要带同一批接缝的 Forsion 桌面端和服务端；手机和网页版这一轮没有。「同步」这一行、图标上的点和进度环、退出确认、「我的云盘」的图标要带对应接缝的桌面端，更早的版本上没有这几样，别的照常。

- New **Penzor Cloud Space**: see and manage what you keep in Forsion Cloud from the desktop app. It opens on an overview: how much you store, a bar split by ledger, four cards (Vault sync, Amadeus Cloud, App files, Exports; the two with a limit each get their own bar, which turns to a warning color at 90%) and your largest files. The left panel is a tree of places; pick a vault, an app, Exports or Trash and the main area becomes a file table with details on the right.
- What you can do depends on the ledger: app files can be downloaded, renamed, moved, moved to trash, restored, deleted permanently or rolled back to an earlier version; exports can be downloaded, renamed and deleted; synced vaults and Amadeus Cloud are view and download only (deleting a synced file here would delete it on every device). Downloads go to your Downloads folder. Remote sync now sends the device name with each write, so Penzor Cloud can show which device wrote a synced file.
- The first row in the left panel is **Sync**: switches, status and syncing devices for your vault, Agents & memory and plugin data, all on one page. Expand the vault row to see its schedule, direction, files that weren’t uploaded and where it lives in the cloud. When you sign in on another computer and the cloud already has a vault, you choose here: merge both, use the cloud copy (confirmed once in place; this computer’s differing files move to a backup folder first) or don’t sync notes on this computer yet. Going over the limit is explained here too; files that don’t fit stay on this computer and nothing is deleted.
- If nothing is syncing or something needs your decision, Penzor Cloud opens on the Sync page. Its Ribbon icon shows a dot when something needs your decision or the last sync failed, and a progress ring while the vault syncs or files transfer (file transfers take precedence).
- Penzor Cloud also works as a drive: **My drive** sits in the left panel, the toolbar has Upload (its menu also uploads a whole folder, recreated level by level in the cloud) and New folder, and you can drag files straight from Finder into the file table, or onto a folder's row to put them in that folder. My drive counts toward the 10 GB for app files. Duplicate names become "name (1)", files are limited to 50 MB each for now, and if a batch won't fit, none of it starts and you're told how much space is missing.
- Uploads and downloads queue in the background (three at a time in each direction) and keep going when you switch Spaces. Files on their way into the folder you're viewing show up in the table with their progress, and every transfer is listed in a floating card at the bottom right of the main area: progress, speed and time left for each, with pause, resume, cancel and retry, plus Show in folder for finished downloads. Left alone for 10 seconds it shrinks to a pill; once everything is done it disappears after 4 seconds, and it stays while anything didn't finish. If you're elsewhere you get a short notice when transfers finish or fail. Quitting Forsion while something is still transferring asks first. Resuming after a pause and retrying both start the file over.
- Multiple selection: ⌘-click to add, ⇧-click for a range, ⌘A for everything; the toolbar turns into a batch bar. App files can be downloaded, moved or moved to trash in bulk; synced vaults and Amadeus Cloud can be downloaded in bulk. Downloading several files at once puts them in a "Penzor Cloud <date>" folder inside Downloads.
- Needs a Forsion desktop app and server with the matching hooks; not on phones or the web yet. The Sync row, the dot and progress ring on the icon, the quit prompt and the My drive icon need a desktop app with the matching hooks; on older versions those are missing and everything else works.

- 新增 **「使用指南」Space**：Forsion 的说明书，排在 Space 列表末尾（图标是一本书）。左栏按等级列出章节（Lv.1 初来乍到 → Lv.4 融会贯通，外加「新版本」一组），正文是只读的 Amadeus 页，下面是本章任务。每章导语下面有一张示意图，画出这一章要找的地方在界面哪儿（1–3 处，带编号，正文里的 ①②③ 对得上），跟着当前亮暗和主题色走。本级任务做完，下一级解锁；任务就是你平时的操作（发消息、建笔记、换主题……），以前做过的直接算数。
- 每项任务都有 **「带我去」**：切到对应的 Space，在真界面上圈住要点的那一处，旁边一张小卡写这一步做什么（「第 n 步，共 m 步」），你自己点；做完这一步圈自动挪到下一步。不压暗屏幕、不挡点击，「知道了」或 Esc 收起，「不再提示」等于关掉指南「···」菜单里的「现场指引」（缺省开）；目标找不到时直接打开对应功能。这一章的任务同时跟到那个 Space 的右栏（伴读），做完一项就地打勾，整章做完伴读自己收起。手机和网页上做不了的任务写着「在电脑上做」，不挡升级。
- 右栏是本级进度和下一级，**「问 Tangu」** 就是 Tangu 的对话本身：同一个输入框、消息、模型和附件，本章内容挂在输入框上方当引用，问完不用离开指南；这条对话一直接着用，下次打开历史还在，Tangu 的会话列表里也看得到。换一章，引用跟着换。用过一阵的话，右上角「···」里可以全部解锁，也能关掉「使用指南提醒」。
- 每升一级，收件箱来一封「接下来试试这几件事」，信下面就是那几章的任务，可以直接「带我去」；装上带「新版本」章节的新版本后，也会来一封这个版本可以体验的清单。收件箱里同时只留一封未读的指南信。等级只管解锁章节，Forsion 现有的成就照常算。
- 需要带同一批接缝的 Forsion 桌面端；更早的桌面端上不出现这个 Space。现场圈注和指南里的对话要带对应接缝的桌面端，不够新时「带我去」直接打开对应功能，「问 Tangu」去 Tangu 里开一条带上本章内容的新对话。

- New **Guide Space**: a manual for Forsion, at the end of your Space list (the book icon). The left panel lists chapters by level (Lv.1 Getting started to Lv.4 Going further, plus a What's new group), the page itself is a read-only Amadeus page, and the chapter's tasks sit below it. Every chapter has a diagram under its intro showing where in the app the things it covers live (one to three numbered spots that match the ①②③ in the text), drawn in your current light/dark mode and accent color. Finish a level's tasks to unlock the next one. Tasks are things you do anyway (send a message, create a note, change the theme), and whatever you've already done counts.
- Every task has **Take me there**: it switches to the right Space and rings the spot to click on the actual screen, with a small card saying what this step does ("Step n of m"), and you click it yourself; once that step is done the ring moves to the next. Nothing is dimmed or blocked. Got it or Esc dismisses it, and Don't show again turns off On-screen hints in the guide's "···" menu (on by default). If the spot can't be found, it opens the feature directly. The chapter's tasks follow you into that Space's right panel, each one ticks off as you finish it, and the panel closes itself once the chapter is done. Tasks that can't be done on a phone or in the browser say "Do it on your computer" and don't hold you back.
- The right panel shows the level's progress and the next level, and **Ask Tangu** there is Tangu's own chat: the same input, messages, models and attachments, with the current chapter attached above the input as a quote, so you can ask without leaving the guide. It keeps using one conversation, so your history is there next time, and it also shows up in Tangu's chat list. Switch chapters and the quote follows. If you've been around a while, unlock everything from the ··· menu; the same menu turns Guide reminders off.
- Each new level brings a letter to your inbox, "try these next", with that level's tasks right under it and a Take me there button on each. After an update that adds What's new chapters you get a list of what to try in that version. Only one unread guide letter stays in your inbox at a time. Levels only unlock chapters; Forsion's existing achievements count as usual.
- Needs a Forsion desktop app with the matching hooks; on older versions the Space doesn't appear. On-screen hints and the chat in the guide need a desktop app with the matching hooks; on older versions Take me there opens the feature directly and Ask Tangu opens a new chat in Tangu with the chapter attached.

- **笔记云同步**：云端笔记库里每个「同步库」文件夹现在会记下是哪几台设备在同步它。桌面端 Cloud 侧的同步库分区头会显示来源设备（本机写「本机」），要比 2.13.4 更新的桌面端才显示。以前开启同步的库会在下次启动时自动补上本机。
- 一台设备把某个库的同步全部关掉后，会从记录里摘掉自己；没有设备在同步了，Cloud 侧就不再把它显示成同步库分区。关闭时没联网的，下次打开 Forsion 时自动补做。
- 桌面端 Cloud 侧可以把根文件夹「设为同步库分区」，或把旧版留下的分区取消掉（需要新版桌面端）。
- 笔记云同步下载附件（比如图片）时，云端存储那边的拒绝访问（链接过期、文件缺失）不再被当成登录失效、让同步停下等你重新登录，而是稍后自动重试。

- **Note cloud sync**: each synced vault folder in your cloud notes now records which devices are syncing it. On the desktop, the synced vault sections on the Cloud side show the device it comes from ("This device" for this one); this needs a desktop app newer than 2.13.4. Vaults you turned sync on for earlier add this device automatically on the next launch.
- When a device turns sync off for everything in a vault, it removes itself from that record; once no device is syncing it, the Cloud side stops showing it as a synced vault section. If the device was offline at the time, this happens the next time Forsion starts.
- On the desktop's Cloud side you can mark a top-level folder as a synced vault section, or remove a section left behind by older versions (needs the new desktop app).
- When note cloud sync downloads an attachment (an image, say) and cloud storage refuses it (an expired link or a missing file), sync no longer takes that as a sign-in failure and stops until you sign in again; it retries a little later instead.

- 「设置 → Forsion 云端」重新分组：左栏收成账号、会员与额度、背包、插件投稿、帮助与诊断几项；账号下分个人主页、账号资料与安全，会员与额度下分积分与邀请、用量记录，帮助与诊断下分反馈与诊断数据。各页能在设置搜索里按关键词找到。分组要比 2.13.4 更新的桌面端；2.13.4 及更早上这些页面照旧平铺在左栏。
- 插件投稿页新增详细描述、标签（最多 8 个）、最低 / 最高 Forsion 版本和支持的端；ZIP 投稿会自动读取清单里的版本要求，手填的值要和清单一致。投稿后自动分配唯一插件 ID，名字可以和别的插件重复，更新沿用同一个 ID。
- 公告弹窗改成排队出：Forsion 自己的协议更新提示和更新内容（What's new）在前，同一时间只露一张，前一张关了下一张才出；全屏引导开着时先不弹。要带同一批接缝的桌面端，更早的版本上照旧直接弹。

- Settings → Forsion Cloud is regrouped: the sidebar now has Account, Membership & quota, Backpack, Submissions, and Help & diagnostics. Account holds Profile, Account details and Security; Membership & quota holds Points & invites and Usage; Help & diagnostics holds Feedback and Diagnostic data. Each page can be found by keyword in Settings search. Grouping needs a desktop app newer than 2.13.4; on 2.13.4 and earlier the pages stay listed one by one in the sidebar.
- The Submissions page adds a detailed description, tags (up to 8), minimum and maximum Forsion versions, and supported platforms. ZIP submissions read the version requirements from the manifest, and values you type must match it. Each submission gets a unique plugin ID, names may repeat, and updates keep the same ID.
- Announcements now wait their turn: Forsion's own terms-update notice and What's new come first, only one shows at a time, and the next appears once the previous one is closed; nothing pops up while full-screen onboarding is open. Needs a desktop app with the matching hooks; older versions show announcements right away as before.

## 0.8.3 — 2026-10-13

- 「设置 → Forsion 云端」新增**插件投稿**页：查看自己投稿的审核状态与原因（待审、已上架、已驳回），用 GitHub 仓库、npm 包或 ZIP 投稿，给 ZIP 投稿提交新版本送审。同一页也出现在商店左栏的「投稿」里。
- **诊断数据**（「账号」页里的可选上传，默认关闭）补了几样，方便 Forsion 团队定位问题：最近 7 天每次运行的状态和报错原因、模型调用与工具的用量和耗时，这台电脑的内存与磁盘余量，以及引擎最近的运行日志（引擎日志要比 2.13.3 更新的桌面端才有）。这几样里没有对话内容，跟着「上传诊断数据」的总开关走。
- 诊断数据新增一个开关「**包含 Agent 的人设、记忆与进化记录**」：每个 Agent 的人设（包括配置里的描述和开发者指令）、记忆和还没整理的记忆候选、进化记录、写给你的协作说明、最近 7 天的日志和记忆整理记录，项目记忆，团队的设定，以及你的用户画像。这些是你写的设定和 Agent 从对话里记下的事实，常见格式的密钥会遮掉，其余原样上传；不打开这个开关，这些文件不会被读取。已经开着上传的账号升级后这一项是关的；新打开上传时它默认开着，可以先关掉再打开上传。卡片上原来那句「不会上传 Agent 的记忆与人设」相应改了。
- 修复：云端托管模型的编号在诊断数据里被当成密钥遮掉，看不出用的是哪个模型。
- 修复：诊断数据里 Agent 与团队配置的提纲，在手动改过的配置文件上可能把别处的一小段文字带上去。现在按配置文件的语法解析，只带选项和开关的值；引擎不认识的键名只记长度。

- **Submissions** is a new page under Settings → Forsion Cloud. See the review status and reasons for what you have submitted (pending, listed, rejected), submit from a GitHub repository, an npm package or a ZIP, and send a new version of a ZIP submission for review. The same page also appears under Submit in the Store.
- **Diagnostic data** (the optional upload on the Account page, off by default) now covers a few more things that help the Forsion team track problems down: each run from the last 7 days with its status and error reason, usage and timing of model calls and tools, this computer's free memory and disk space, and the engine's recent log output (engine logs need a desktop app newer than 2.13.3). None of these contain conversation text, and they follow the main "Upload diagnostic data" switch.
- Diagnostic data has a new switch, **Include agent personas, memory and evolution records**: each agent's persona (including the description and developer instructions in its configuration), its memory and the memory candidates it hasn't consolidated yet, its evolution record, its collaboration notes for you, the last 7 days of its logs and memory-consolidation activity, project memory, your teams' charters, and your user profile. These are instructions you wrote and facts your agents noted from conversations; keys in common formats are masked and everything else is uploaded as is. Unless this switch is on, those files are never read. If uploads were already on, this starts off after the update; when you turn uploads on for the first time it starts on, and you can turn it off first. The line on the card that said agent memory and personas are never uploaded has been changed to match.
- Fixed: the id of a cloud-hosted model was masked as if it were a key, so diagnostic data didn't show which model was in use.
- Fixed: the outline of agent and team configuration in diagnostic data could pick up a short piece of text from elsewhere in a hand-edited configuration file. The file is now parsed by its syntax and only option and switch values are kept; key names the engine doesn't know are recorded by length only.

## 0.8.2 — 2026-10-11

- 「设置 → Forsion 云端」新增**个人主页**：和网页个人中心是同一张主页，现在在桌面端也能看、能改。可以就地改头像、昵称、简介和链接，选哪几件作品放上去；在「装饰」里换封面和头像框，调整各模块的顺序、显示与否、是否给访客看，给公开页选配色和明暗。
- 可以把主页公开或设回私有。公开前会列出每一块给不给访客看；邮箱、手机号、会员到期日、积分和额度不会出现在主页上。公开后可以复制地址，或在浏览器里查看公开页。
- 在桌面端，主页跟 Forsion 当前的主题走（主题色、背景色、明暗）。装饰里的「公开页的配色」「公开页的明暗」只管访客在公开页上看到的。
- 需要 Forsion 云端 2.3.37 或更新版本；更早的云端上这一页只显示一句说明。

- **Profile** is a new page under Settings → Forsion Cloud. It is the same profile as in the web account center, and you can now view and edit it on the desktop. Change your photo, nickname, bio and links in place and choose which works to feature. Under Decorate you can change the cover and avatar frame, pick the public page's color scheme and appearance, and reorder sections, show or hide them, and decide whether visitors see them.
- You can make your profile public or private again. Before it goes public you see what visitors will get, section by section; your email, phone number, membership expiry, points and quota never appear on your profile. Once it's public you can copy its address or view the public page in your browser.
- On the desktop your profile follows Forsion's current theme (theme color, background and light or dark appearance). "Public page color scheme" and "Public page appearance" under Decorate only set what visitors see on the public page.
- Requires Forsion Cloud 2.3.37 or later. On earlier versions the page shows a short note instead.

## 0.8.1 — 2026-10-06

- 商店左栏新增「会员与积分」分区，三页：**会员**（当前档位与积分余额；按月付 / 季付 / 年付选档位，付款在浏览器的支付页完成，回到应用后自动刷新）、**积分**（积分包，付款后即时到账）、**物品**（用积分兑换，在应用内直接完成，兑换后进背包）。需要带商店页面位的 Forsion 桌面版；更老的桌面版上不出现这个分区，其余功能不受影响。
- 兑换没收到结果时不会自动重试，会提示先到背包看有没有到账。
- 「应用市场 / 插件商店」的称呼统一成「商店」。

- The store sidebar has a new **Membership & points** section with three pages. **Membership** shows your current plan and points balance and lets you pick a plan billed monthly, quarterly or yearly; payment happens on the payment page in your browser and the app refreshes when you come back. **Points** lists point packs, credited as soon as you pay. **Items** lets you redeem items with points inside the app; redeemed items go to your backpack. This needs a Forsion desktop version that provides store pages. On older desktop versions the section doesn't appear and everything else works as before.
- If a redemption gets no response, the app doesn't retry on its own. It asks you to check your backpack first.
- “Market” and “plugin store” are now called the store everywhere.

## 0.8.0 — 2026-10-05

- 新增「诊断数据」：在「设置 → Forsion 云端 → 账号」里可以打开，默认关闭。打开后，这台电脑会定期上传一份 Forsion 信息快照到你的 Forsion 账号，帮助我们排查问题、改进产品。多久上传一次由 Forsion 团队设定，默认每天一次，也可能只在需要时采集。快照包含应用与系统版本、模型与语音的选择、后台 Agent 与插件设置里的开关和数值、MCP 服务与消息通道的名字、Agent 与团队的配置（提示词只记长度，不带内容），以及已安装的插件、技能、主题和 Space 的名字。
- 两项带个人内容的数据各有一个开关，打开上传之前就能先关：会话内容（这台电脑上的对话文字、Agent 的思考过程和用到的工具名，包括团队成员、讨论、委派在后台做的那部分；工具读写的内容和附件本身不带，消息里出现的文件名、Agent 在回复里复述的笔记或文件内容会在其中；常见格式的密钥会遮掉，其余原样上传），以及活动日志（含对话开头的几十个字和笔记文件名）。这两项每次只上传还没上传过的部分，最多往前 7 天。
- 保存在这台电脑上的登录凭据与 API 密钥、笔记文件、Agent 的记忆与人设、插件数据不会上传。
- 云端保留每台电脑最近 14 天的快照；关闭后不再上传。

- Diagnostic data: you can now turn this on under Settings → Forsion Cloud → Account. It is off by default. When it's on, this computer periodically uploads a snapshot of its Forsion setup to your Forsion account to help us troubleshoot problems and improve the product. The Forsion team sets how often: once a day by default, or only when a snapshot is needed. The snapshot covers app and system versions, your model and voice choices, the switches and numeric values in background agent and plugin settings, the names of MCP servers and message channels, agent and team configuration (prompts are recorded by length only, never their text), and the names of installed plugins, skills, themes and Spaces.
- Two kinds of personal content each have their own switch, which you can turn off before you turn uploads on: conversations (the text of conversations on this computer, the agent's reasoning and the names of the tools it used, including the background work of team members, discussions and delegated tasks; what those tools read or wrote and the attachments themselves are left out, while file names that appear in messages and anything the agent repeated from your notes or files in its replies are included; keys in common formats are masked and everything else is uploaded as is), and the activity log (including the first few dozen characters of conversations and the names of note files). Each upload only includes the part of these two that hasn't been uploaded yet, going back at most 7 days.
- The sign-in credentials and API keys saved on this computer, your note files, agent memory and personas, and plugin data are never uploaded.
- The cloud keeps each computer's snapshots from the last 14 days. Turning the feature off stops uploads.

## 0.7.1 — 2026-09-30

- 「设置 → Forsion 云端」新增游戏背包式物品格子，可查看物品数量、品质和详情；已领取的兑换券点击后才展示卡密。
- 支持管理员用 JSON 定义的新物品，确认使用后扣除一件并展示实际效果与动画：获得积分、额度重置卡或恢复额度。需要 Server 2.3.28 或更新版本。
- 新版 Forsion 桌面端可从左下角头像菜单直接打开背包。

- Adds a game-style item grid in Settings → Forsion Cloud → Backpack, with quantities, rarity and details. Voucher keys are only revealed when you choose to view them.
- Supports items defined by administrators in JSON. Confirming use consumes one item and shows its effects and animation: points, reset cards or restored quota. Requires Server 2.3.28 or later.
- Newer Forsion Desktop builds can open the backpack directly from the avatar menu.


## 0.7.0 — 2026-09-29

- 新增公告：Forsion 发布重要通知时，打开桌面端会弹出一张公告卡片；点「知道了」或关掉之后就不再出现。公告里的链接会在浏览器中打开。
- 在「设置 → Forsion 云端 → 额度与积分」里使用额度重置卡后，会播放用卡动画，展示今日与本周额度恢复了多少。需要较新的 Forsion 桌面端；旧版本仍在页面上显示使用前后的对比。
- 「积分自动抵扣」已下线：AI 额度用完后不再自动扣积分继续使用。积分仍然可以兑换额度重置卡。

- Announcements: when Forsion posts an important notice, it pops up as a card when you open the desktop app. Once you choose "Got it" or close it, it doesn't show again. Links in announcements open in your browser.
- Using a quota reset card in Settings → Forsion Cloud → Quota & points now plays the reset card animation, showing how much of today's and this week's quota is back. This needs a newer Forsion Desktop build; older builds keep showing the before-and-after on the page.
- "Pay with points automatically" has been retired: points are no longer spent automatically when your AI quota runs out. You can still use points to get quota reset cards.

## 0.6.0 — 2026-09-29

- 「设备互联」的云端那一半改由本包提供：经 Forsion 云端中转让其他设备连上这台电脑、向设备列表报告这台电脑的状态，以及查看、改名、换图标、移除设备和在浏览器中打开设备。用法和之前一样。
- 服务器重启的那几秒里连不上时，不再清掉这台电脑的配对重新登记，设备列表里不会因此多出一台台离线的重复设备。
- 没装本包的桌面端不再列出账号下的其他设备，也不经云端中转接受连接；同一局域网直连和「允许其他设备连接本机」照常可用。
- 需要较新的 Forsion 桌面端才会启用；旧桌面端上本包照旧提供 0.5 的功能。

- Device connectivity's cloud half now comes from this package: the Forsion cloud relay that lets your other devices reach this computer, reporting this computer's status to your device list, and viewing, renaming, changing the icon of, removing and opening devices in your browser. Everything works as before.
- If the connection drops for a few seconds while the server restarts, this computer keeps its pairing instead of registering again, so your device list no longer fills up with offline duplicates.
- Desktops without this package no longer list the other devices on your account or accept connections through the cloud relay; same-network direct connections and "Allow other devices to connect" keep working.
- This needs a newer Forsion Desktop build; on older desktops this package keeps providing the 0.5 features.

## 0.5.1 — 2026-09-29

- 从桌面端打开账号中心或充值页时，网址里不再带登录令牌，改为一次性交接码：60 秒内有效、只能用一次，不会留在浏览器历史里。需要服务端更新后才生效，在这之前照旧打开。
- 兑换额度重置卡时，如果单价刚好被调整，不会按新价格直接扣积分：页面会提示并显示新价格，请确认后再兑换。
- 用量页的消耗百分比与网页个人中心写法一致（例如 3%，不再写成 3.0%）。
- 附上随包带的第三方开源组件的许可声明。

- Opening the account center or the top-up page from the desktop no longer puts your sign-in token in the address. A one-time handoff code is used instead: it works once, expires after 60 seconds and doesn't stay in your browser history. This takes effect once the server is updated; until then these pages open as before.
- If the reset card price changes while you're exchanging points, you are no longer charged the new price right away: the page tells you, shows the new price and asks you to confirm again.
- Usage percentages are written the same way as on the web account center (for example 3%, not 3.0%).
- Adds the license notices for the open-source components bundled in this package.

## 0.5.0 — 2026-09-29

- 设置里新增「Forsion 云端」，和账号有关的事在桌面端就能办完：
  - 账号：头像、昵称、绑定的手机和邮箱、会员档位与到期日，以及这台电脑上登录过的账号；
  - 额度与积分：今日和本周的 AI 额度、额度重置卡（使用和用积分兑换）、积分余额与充值、后台额度（Muse 与自动化使用）、邀请码和兑换码；
  - 安全：绑定或更换手机和邮箱、修改密码、退出所有设备、注销账号；
  - 用量记录：最近 7、30、90 天的请求次数、成功率和 AI 额度消耗；
  - 反馈：提交问题和建议，并直接在桌面上看到回复。
- AI 额度统一只显示剩余百分比，进度条按剩余填充；额度为 0 时显示 0%，不再误显示成「不限」。
- 改密码的规则与服务端一致并写在界面上；只绑定了邮箱也能用验证码改密码，也可以直接用当前密码修改。
- 充值积分会直接打开充值页；已下线的周重置卡不再出现。
- 需要较新的 Forsion 桌面端，这些页面才会出现；旧桌面端上本包不显示它们，账号设置照旧用桌面端自带的那一页。

- Settings now has a Forsion Cloud section, so you can take care of your account without leaving the desktop app:
  - Account: your photo, nickname, linked phone and email, membership tier and expiry date, and the accounts you've signed in with on this computer;
  - Quota & points: today's and this week's AI quota, quota reset cards (use one or exchange points for more), your points balance and top-ups, the background quota used by Muse and automations, invite codes and redemption codes;
  - Security: link or change your phone and email, change your password, sign out everywhere, delete your account;
  - Usage: requests, success rate and AI quota used over the last 7, 30 or 90 days;
  - Feedback: send issues and suggestions, and read replies right in the app.
- AI quota is always shown as the percentage left, and the bars show what remains; a quota of 0 now reads 0% instead of Unlimited.
- Password rules match the server and are listed on screen. You can change your password with a verification code even if you only linked an email, or directly with your current password.
- Buying points opens the points page directly, and the retired weekly reset card no longer appears.
- These pages need a newer Forsion Desktop build. On older desktops this package doesn't show them, and account settings stay on the page the desktop already has.

## 0.4.0 — 2026-09-28

- 笔记的云端同步与协作从 Forsion 本体搬入本包:云端笔记库镜像、按条目同步、与我共享、页面分享 / 发布 / 在线成员,行为与之前一致。没装本包的桌面端不再显示云端笔记库、云同步与分享入口。
- 需要较新的 Forsion 桌面端才会启用;旧桌面端上本包只提供 0.3 的功能,不影响使用。

Cloud sync and collaboration for notes now ship in this package, moved over from Forsion itself with their behavior unchanged: the cloud vault mirror, per-item sync, shared-with-me, page sharing / publishing / presence. Desktops without this package no longer show the cloud vault, cloud sync or sharing entry points.
This needs a newer Forsion Desktop build; on older desktops this package keeps providing the 0.3 features and nothing else changes.

## 0.3.0 — 2026-09-28

- 账号登录态从 Forsion 本体搬入本包:登录、登出、切换账号、账号状态与登录态自动续期都由本包提供,行为与之前一致。没装本包的桌面端不再显示账号卡、Forsion 设置页与登录入口。
- 「设置 → 同步 → 本地库远程同步」里的「Forsion 云端」后端也搬入本包;没装本包的桌面端不再列出这一项。
- 需要较新的 Forsion 桌面端才会启用以上两块;旧桌面端上本包只提供 0.2 的功能,不影响使用。

Account sign-in now ships in this package, moved over from Forsion itself with its behavior unchanged: signing in, signing out, switching accounts, account status and keeping you signed in. Desktops without this package no longer show the account card, the Forsion settings page or the sign-in entry points.
The "Forsion cloud" backend under Settings → Sync → Remote sync of the local vault ships here too; desktops without this package no longer list it.
Both need a newer Forsion Desktop build; on older desktops this package keeps providing the 0.2 features and nothing else changes.

## 0.2.0 — 2026-09-27

- Forsion Connect(Coding Space 项目发布、应用商店上架申请、预览态 AI 代理)从 Forsion 本体搬入本包,行为与之前一致。预览页里的 `window.forsion`(`/forsion-connect.js`)与 `/__forsion/*` 云端代理也随之由本包提供。
- 需要较新的 Forsion 桌面端才会启用 Connect;旧桌面端上本包只提供云端账号功能,不影响使用。

Forsion Connect (Coding Space project publishing, app store listing requests, and the preview-mode AI proxy) now ships in this package, moved over from Forsion itself with its behavior unchanged. The `window.forsion` SDK served to preview pages (`/forsion-connect.js`) and the `/__forsion/*` cloud proxy come from this package as well.
Connect is enabled on newer Forsion Desktop builds only; on older desktops this package keeps providing the cloud-account features and nothing else changes.

## 0.1.0 — 2026-09-27

- 首个版本。Forsion 云端账号相关的桌面功能首次从 Forsion 本体搬出,作为内置插件随桌面端发布、自动更新:个人中心与会员页入口、额度视图与重置卡、后台额度转换,以及反馈中心提交。
- 插件以当前账号身份调用 Forsion 云端 API 的通用接口(`cloud:fetch`)也在这个包里,行为与之前一致。

First release. The cloud-account features of Forsion Desktop now ship as a built-in plugin that updates on its own: the account center and membership page shortcuts, the quota view and reset cards, background quota conversion, and feedback submission. The shared interface plugins use to call the Forsion cloud API as the signed-in account (`cloud:fetch`) is part of this package too, unchanged in behavior.
