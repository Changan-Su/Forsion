# Forsion Extend

Forsion Extend 是 Forsion 桌面端内置的扩展，负责和你的 Forsion 云端账号有关的一切。它随桌面端一起安装，在后台自动更新，不需要单独下载或设置。

## 它能做什么

- **登录与账号**：登录 Forsion，在这台电脑登录过的账号之间切换，退出登录。登录状态会自动续期，经常使用就不用反复登录。
- **设置里的「Forsion 云端」**：
  - **账号**：头像、昵称、绑定的手机和邮箱，会员档位与到期日，这台电脑上的账号。
  - **微信剪藏助手**（在「账号 → 登录与资料」里，云端开了这个功能才出现）：拿一个绑定码，在微信里发给 Forsion 企业微信号完成绑定；之后发给它的链接会剪藏进你云端智库的 Plugins/wechat-helper。可以解绑。
  - **个人主页**：和网页个人中心是同一张主页。可以改简介和链接、选放上去的作品，换封面和头像框，决定显示哪些模块，给公开页选配色和明暗；可以公开或设回私有，公开后能复制地址、在浏览器里查看。公开页开在网页个人中心的域名上。需要 Forsion 云端 2.3.37 或更新版本。
  - **额度与积分**：今日和本周还剩多少 AI 额度，额度重置卡，积分余额与充值，后台额度（Muse 与自动化使用），邀请码和兑换码。
  - **背包**：以物品格子查看云端资产，重置卡与允许叠放的自定义物品显示数量，卡券可查看、复制卡密。自定义物品支持双语外观、品质、确认使用与成功效果；使用逻辑由云端执行。左下角头像菜单也可直接打开。
  - **插件投稿**：查看自己投稿的审核状态与原因，用 GitHub 仓库、npm 包或 ZIP 投稿，给 ZIP 投稿提交新版本送审。同一页也直接出现在商店左栏的「投稿」里。
  - **安全**：绑定或更换手机和邮箱，修改密码，退出所有设备，注销账号。
  - **用量记录**：最近 7、30、90 天的请求次数、成功率和 AI 额度消耗。
  - **反馈**：提交问题和建议，在桌面上查看回复。
- **商店里的「会员与积分」**（需要较新的 Forsion 桌面端；旧版本上不出现）：商店左栏多出会员、积分、物品三页。会员档位和积分包在应用里挑，付款在浏览器的支付页完成；物品用积分兑换，在应用里直接完成，兑换到的卡密当场可以复制，之后在背包里也能再看。
- **公告**：Forsion 发布的重要通知会在你打开桌面端时弹出，看过就不再出现；公告里的链接在浏览器中打开。
- **使用指南**（0.9，需要较新的 Forsion 桌面端；旧版本上不出现）：Space 列表末尾那本书。Forsion 的说明书，按等级解锁，每章带任务和「带我去」；任务做完的进度存在这台电脑上，升级时收件箱会来一封「接下来试试这几件事」。
- **笔记云同步与协作**：云端笔记库、按条目同步、与我共享，以及页面分享、发布和在线成员。
- **设备互联**：让你的其他设备经 Forsion 云端连上这台电脑；账号下的设备可以查看、改名、换图标、移除，或在浏览器中打开。
- **Forsion Connect**：把 Coding Space 里的项目发布成网页、申请上架商店；预览项目时也能用上 Forsion 的 AI。「Forsion 云端 → 我的网页」列出你发布过的所有网页（包括让 Tangu 发的），桌面、网页和手机上都能复制链接、下线、申请上架或撤回。
- **让 Tangu 提交商店更新**（0.9.5，需要较新的 Tangu 引擎；旧引擎上不出现）：在对话里说「我在 GitHub 上发了 v1.1.0，把商店更新也提交了」，Tangu 先检查读到的新版本，再弹审批卡请你确认，确认后送审；也可以只改商店信息。只能更新你自己的投稿，ZIP 包仍在投稿页上传。提交后对话里有一张「商店更新」卡片，显示待审核、已通过或没通过（附审核意见）。可以在「设置 → 插件」的引擎插件里关掉。
- **诊断数据**（可选，默认关闭）：在「Forsion 云端 → 账号」里打开后，这台电脑会定期上传一份 Forsion 信息快照到你的账号，帮助 Forsion 团队排查问题、改进产品；多久上传一次由 Forsion 团队设定（默认每天一次，也可以只在需要时采集）。包含应用与系统版本、这台电脑的内存与磁盘余量、模型与语音的选择、后台 Agent 与插件设置里的开关和数值、MCP 服务与消息通道的名字、Agent 与团队的配置（描述与提示词只记长度）、已安装的插件与技能名单，以及最近 7 天的运行记录（每次运行的状态和报错原因，模型调用与工具的用量、耗时，引擎最近的运行日志；不带对话内容和工具读写的内容）。会话内容（这台电脑上的对话文字、思考过程和工具名，含团队成员、讨论、委派在后台做的那部分；不含工具读写的内容和附件本身，消息里出现的文件名、Agent 在回复里复述的笔记或文件内容会在其中；常见格式的密钥会遮掉，其余原样上传）与活动日志各有一个开关，可以先关掉再打开上传；这两项每次只上传还没上传过的部分，最多往前 7 天。Agent 的人设、记忆与进化记录（每个 Agent 的人设和配置里的描述与开发者指令、记忆和记忆候选、进化记录、写给你的协作说明、最近 7 天的日志和记忆整理记录、项目记忆，以及团队的设定和你的用户画像；每次上传它们当前的内容，很长的会截断，常见格式的密钥会遮掉，其余原样上传）也有一个开关，同样可以先关掉。保存在这台电脑上的登录凭据与 API 密钥、笔记文件、Agent 的资料库、插件数据不会上传。

## 设置在哪里

打开「设置 → Forsion 云端」：左侧是账号、个人主页、额度与积分、背包、插件投稿、安全、用量记录、反馈这几页，同步与云端地址也在这里。云空间、AI 大脑和主题在网页个人中心管理，账号页底部有「在浏览器中打开个人中心」。

没看到「Forsion 云端」？到「设置 → 插件」确认 Forsion Extend 已启用（启用或停用后要重启 Forsion 才生效）。较早版本的 Forsion 桌面端会把这几页显示在插件详情页里。

---

Forsion Extend is built into Forsion Desktop and takes care of everything to do with your Forsion cloud account. It is installed with the desktop app and updates itself in the background, so there is nothing to download or set up.

## What it does

- **Signing in**: sign in to Forsion, switch between the accounts you've used on this computer, and sign out. Your sign-in renews itself, so regular use doesn't keep asking you to sign in.
- **Forsion Cloud in Settings**:
  - **Account**: your photo, nickname, linked phone and email, membership tier and expiry date, and the accounts on this computer.
  - **WeChat Helper** (under Account → Sign-in & details; it only appears when the cloud has it turned on): get a binding code and send it to the Forsion WeCom account in WeChat; links you send it afterwards are clipped into Plugins/wechat-helper in your cloud vault. You can unbind.
  - **Profile**: the same profile as in the web account center. Edit your bio and links, choose which works to feature, change the cover and avatar frame, decide which sections to show, and pick the public page's color scheme and appearance. Make it public or private again; once public you can copy its address or view it in your browser. The public page lives on the web account center's domain. Requires Forsion Cloud 2.3.37 or later.
  - **Quota & points**: how much AI quota is left today and this week, quota reset cards, your points balance and top-ups, the background quota used by Muse and automations, invite codes and redemption codes.
  - **Backpack**: view cloud items in a slot grid, with stacked reset cards, configurable items and voucher keys you can reveal and copy. Custom items support bilingual names, rarity, confirmed use and success effects, with account changes executed by the server. Open it from the avatar menu in the lower left.
  - **Submissions**: see the review status and reasons for what you have submitted, submit from a GitHub repository, an npm package or a ZIP, and send a new version of a ZIP submission for review. The same page also appears under Submit in the Store.
  - **Security**: link or change your phone and email, change your password, sign out everywhere, delete your account.
  - **Usage**: requests, success rate and AI quota used over the last 7, 30 or 90 days.
  - **Feedback**: send issues and suggestions, and read replies in the app.
- **Membership & points in the Store** (needs a newer Forsion Desktop; it doesn't appear on older versions): the Store's left column gains Membership, Points and Items pages. You pick a plan or a point pack in the app and pay on the payment page in your browser; items are redeemed with points right in the app, the key is shown for copying, and you can view it again later in your backpack.
- **Guide** (0.9, needs a newer Forsion Desktop; it doesn't appear on older versions): the book at the end of your Space list. A manual for Forsion that unlocks level by level, with tasks and a Take me there button in every chapter. Progress is kept on this computer, and each new level brings an inbox letter with what to try next.
- **Announcements**: important notices from Forsion pop up when you open the desktop app and don't show again once you've read them; links in them open in your browser.
- **Note sync and collaboration**: the cloud vault, per-item sync, shared with me, and page sharing, publishing and presence.
- **Device connectivity**: let your other devices reach this computer through the Forsion cloud, and view, rename, change the icon of, remove or open in your browser the devices on your account.
- **Forsion Connect**: publish Coding Space projects as web pages and apply for a store listing; project previews can use Forsion's AI too. Forsion Cloud → My web pages lists every page you have published (including the ones Tangu published for you); on desktop, web and mobile you can copy a link, take a page down, or apply for or withdraw a store listing.
- **Tangu submits Store updates** (0.9.5, needs a newer Tangu engine; it doesn't appear on older ones): say "I published v1.1.0 on GitHub, submit the Store update" and Tangu checks the new version it finds, asks you on an approval card, then sends it to review. It can also change just the store info. Only your own submissions can be updated, and ZIP packages are still uploaded on the Submissions page. After submitting, a Store update card in the chat shows whether it is in review, approved, or not approved (with the review note). Turn it off among the engine plugins in Settings → Plugins.
- **Diagnostic data** (optional, off by default): when you turn it on under Forsion Cloud → Account, this computer periodically uploads a snapshot of its Forsion setup to your account to help the Forsion team troubleshoot problems and improve the product; the Forsion team sets how often (once a day by default, or only when a snapshot is needed). It covers app and system versions, this computer's free memory and disk space, your model and voice choices, the switches and numeric values in background agent and plugin settings, the names of MCP servers and message channels, agent and team configuration (descriptions and prompts by length only), the list of installed plugins and skills, and run records from the last 7 days (each run's status and error reason, usage and timing of model calls and tools, and the engine's recent log output; no conversation text and nothing those tools read or wrote). Conversations (the text of conversations on this computer, the agent's reasoning and tool names, including the background work of team members, discussions and delegated tasks; without what the tools read or wrote and without the attachments themselves, though file names that appear in messages and anything the agent repeated from your notes or files are included; keys in common formats are masked, everything else is uploaded as is) and the activity log each have their own switch, which you can turn off before you turn uploads on; each upload only includes the part of these two that hasn't been uploaded yet, going back at most 7 days. Agent personas, memory and evolution records (each agent's persona with the description and developer instructions in its configuration, its memory and memory candidates, its evolution record, its collaboration notes for you, the last 7 days of its logs and memory-consolidation activity, project memory, your teams' charters, and your user profile; each upload carries their current content, with very long ones cut short, keys in common formats masked and everything else as is) have a switch of their own, which you can also turn off first. The sign-in credentials and API keys saved on this computer, your note files, agent libraries, and plugin data are never uploaded.

## Where to find it

Open Settings → Forsion Cloud. The pages on the left are Account, Profile, Quota & points, Backpack, Submissions, Security, Usage and Feedback, and sync and the cloud address live there too. Cloud storage, AI Brain and themes are managed in the web account center; the Account page has a link that opens it in your browser.

Don't see Forsion Cloud? Check that Forsion Extend is turned on under Settings → Plugins (turning it on or off takes effect after you restart Forsion). Older versions of Forsion Desktop show these pages on the plugin's detail page instead.

## License

专有授权，见 [LICENSE](./LICENSE)：仅允许作为 Forsion 的一部分使用与再分发。Proprietary, see [LICENSE](./LICENSE): use and redistribution only as part of Forsion.

## 统一云盘 / Unified drive

蓬洲云默认进入「我的云盘」概览，八个来源统一列出。只有「我上传的」接收上传；同步来源只读，普通应用文件保留管理能力，来源声明只读时隐藏修改。插件数据仅展示元信息。统一用量使用服务端 `/storage/ledger`，T2 阶段只提醒，不新增拦截；失败保留并标注上次统计，旧来源限制仍生效。

Penzor Cloud opens My drive with eight source folders. Uploads go to My uploads; synced sources are read-only, ordinary app files retain management unless the source declares otherwise, and plugin data exposes metadata only. Unified quota is notice-only. Failed refreshes explicitly label the last sample as stale; existing source limits remain in force.

验证 / Validation: `npm run test:vitest -- test/vitest/renderer/penzorData.test.ts test/vitest/renderer/penzorState.test.ts test/vitest/renderer/penzorSync.test.ts`. Real desktop acceptance lives in Genesis `desktop/scripts/penzor-space.e2e.cjs`.

## Web 与原生手机 / Web and native mobile

Web 主入口与原生手机复用本包的账号、会员与积分商店、公告和蓬洲云界面。读取当前登录账号已有的云端资料与云盘，不创建另一份手机账号。手机上传交浏览器 `File`，下载交宿主保存；电脑笔记同步开关、本机设备诊断不在手机上注册。Web 仍使用浏览器下载和标签页，手机付款与公告链接使用系统浏览器。

The Web entry and native mobile reuse Extend's account pages, membership and points store, announcements, and Penzor Cloud. They read the signed-in account's existing cloud data. Mobile uploads use browser `File` objects and downloads use the native host. Desktop note-sync controls and local diagnostics are hidden on mobile. Web keeps its browser downloads/tabs; mobile opens payments and announcement links in the system browser.

宿主契约 / Host contract:

- Web: `window.tangu.unitPage && window.tangu.unitPublicEntry`; mobile: `window.tangu.mobile && window.tangu.extendMobile`. The mobile marker belongs to the bundled, verified Extend loader.
- `ctx.account.status()` returns `{ loggedIn, cloudUrl }`, where `cloudUrl` identifies the account API origin (`https://…/api`). `ctx.account.request(url, init)` accepts absolute same-account `/api/…` URLs, injects authentication in the host, preserves multipart `Blob` bodies and `AbortSignal`, and rejects other origins. Extend never receives the token.
- `window.tangu.onAuthChanged(cb)` fires for sign-in, sign-out and account changes. Extend aborts in-flight requests, clears transfer filenames and directory caches, and ignores old responses. The host must change authentication and notify atomically before another account request can run.
- Mobile `ctx.account.saveDownload(blob, name)` returns `Promise<{ ok: boolean; error?: string }>`; `{ ok: true }` means the host accepted and saved the file. Missing/rejected saving produces a failed transfer. `window.tangu.openExternal(url)` opens the native browser; the existing native `openAccountCenter(section)` is preserved.
- The account adapter's `cloudFetch` and `cloudInvoke` stay private to Extend. They are never assigned to `window.tangu`, so desktop-only host capabilities are not accidentally enabled.

验证 / Validation: `npm run typecheck`; `npx vitest run test/vitest/renderer/webEntry.test.ts test/vitest/renderer/webTransfers.test.ts test/vitest/renderer/penzorState.test.ts`. The focused tests cover mobile registration, native browser/save routing, signed-download fallback, active/queued uploads, sign-out and account switches, late quota responses, and nested-folder cancellation.

## 目录同步 / Folder sync

新版 Genesis 宿主与 Server 配合时，蓬洲云「同步」使用规则表：默认双向同步到云端 `/Forsion/`，子路径可改到 `/Forsion-设备ID/` 或设为不同步。最具体的路径优先；未匹配内容不参与同步。第一次开启和修改范围先预览、再确认。切换目标保留原云端副本，重新选择范围会重新对齐基线，断开的目录不会被当作删除。

文件夹使用独立身份跟踪改名，同名目录合并。数据库沿用宿主按行 ID 的合并，文本安全三方合并；无法合并时保留冲突副本。传输页显示实际文件、方向、字节进度、暂停和重试。human 默认日历仍是 `human/CALENDAR.db`；只有同步到默认目录的内容供网页端默认读取。旧宿主保留原同步页。

With the matching Genesis host and Server, Penzor Cloud provides per-folder bidirectional rules. The deepest path wins; destinations are the default `/Forsion/`, a device directory, or off. Scope changes require a fresh preview. Old destinations are retained; newly selected scopes reconcile before any deletion, and unavailable roots stop reconciliation. Stable directory identities carry renames. Database rows use the host merger, ordinary conflicts retain both versions, and transfers show actual byte progress. `human/CALENDAR.db` remains the shared default calendar. Older hosts keep their original sync page.

Validation: `npm test` and `npm run typecheck`. The filesystem/HTTP two-client suite is `test/vitest/contentSync.test.ts`; renderer acceptance is `test/vitest/renderer/contentRules.test.tsx`. Real desktop acceptance: Genesis `EXTEND_PKG=<built Extend checkout> npm run e2e:contentsync` under the repository devlock.

### 同步提交与凭据续期 / Sync commits and credential refresh

Amadeus 入站拉取和三方合并通过 `CoreHost.compareAndReplace` 提交。桌面实现复用 Genesis 的 `contentSync.withWriteLock`，在与编辑器相同的锁内复查目标字节和会话条件；不匹配时保留本地编辑并重新对账。旧宿主缺少这把共享锁时，入站覆盖会明确失败并保持可重试状态，不能退回无锁替换。该保证针对遵循宿主写锁协议的写入，不承诺与任意外部程序之间的文件系统级 CAS。

REST 请求和 SSE 重连读取当前同账号令牌；旧令牌 401 的完整正文返回后若凭据已续期，REST 最多重试一次。换账号或退出登录时拒绝继续使用旧会话。未完成上传的节点身份先写入本地日志；仅本机创建且服务端确认无内容的节点可被取消，已上传但响应丢失的内容会重新下载保留。

Amadeus downloads and merges commit through `CoreHost.compareAndReplace`. The desktop adapter uses Genesis's `contentSync.withWriteLock` to verify target bytes and session guards under the editor's lock. A mismatch retains local edits and reconciles again. Older hosts without that shared lock reject inbound replacement with a retryable error; they never fall back to an unguarded overwrite. This protects writers participating in the host lock protocol, not arbitrary external processes.

REST requests and SSE reconnects read current credentials for the same account. An old-token 401 can retry once after its complete body arrives if credentials have refreshed; account changes and sign-out reject the old session. Pending node identities are journaled before creation. Cancellation applies only to this device's unpopulated nodes; content uploaded before a lost response is downloaded and preserved.

验证 / Validation: `npx vitest run test/vitest/engine.localCas.test.ts test/vitest/tokenRefresh.test.ts test/vitest/contentSync.test.ts`; `npm run typecheck`; `npm run check:core`. These tests use real temporary files and controlled local/fixture transports, without production accounts or storage.

### macOS sync root identity after a reboot

Local APFS roots retain their volume UUID, inode and available birth time across
restarts; in-process writes still check the current mount device and inode.
Legacy shadows whose device number already changed cannot be silently rebound.
Do not delete their files, cursor, pending deletion or move baselines.

`npm run sync:root:inspect -- /absolute/path/to/amadeus-sync-ACCOUNT.json` is a
read-only inspection. If the owner confirms this is the intended original
directory, quit every application using that Electron profile and repeat with
`--confirm INSPECTION_TOKEN`. The shadow must be the original file directly in
that profile's `userData` directory. Independent profiles (for example, the
installed app while recovering dev) may remain running; the command checks the
target profile's `SingletonLock` and `SingletonSocket`, including stale locks,
before inspection and immediately before writing. It does not infer ownership
from executable names. Separately check whether another profile uses the same
physical note directory before performing recovery on shared directories.
Keep the target profile closed until the command finishes; these checks do not
reserve its single-instance lock against a concurrent relaunch.
The offline command checks the current root and exact shadow again, creates an
exact backup, then changes only root identity. Install the fixed Extend build
before restarting; older builds still compare device numbers after future reboots.
Unknown/network filesystems without a durable volume ID keep the strict mount
check. Regression: `npx vitest run test/vitest/directoryIdentity.test.ts
test/vitest/amadeusLifecycle.saturation.test.ts test/vitest/contentSync.test.ts
test/vitest/rebindSyncRoot.test.ts`.

Local reboot/remount/account regressions: `npm run test:sync-lifecycle` runs with
an isolated temporary home and a loopback-only network guard. It includes fresh
Node processes, abrupt child termination after a synthetic cloud commit, changed
mount identities, delayed writes and account transitions. All notes, accounts,
shadows and cloud responses are fixtures; no production account, user vault,
installed Electron window or real disk unmount is used.

Official inbox state is stored in the account database and exposed to Genesis through the optional first-party
`ctx.app.provideInboxChannel` seam. Native Agent/system messages retain their engine storage.
Run `npx vitest run test/vitest/renderer/inbox.test.ts` for provider routing and lifecycle checks.
