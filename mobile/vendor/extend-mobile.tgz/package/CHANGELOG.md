# 更新日志

## 0.10.5 — 2026-11-12

- 接通新版桌面、网页和手机宿主的官方收件箱：历史消息和归档从当前账号读取，已读、归档和删除状态在各端同步，附件领取沿用同一份记录。修复新版网页因缺少接入通道而显示空收件箱的问题；需要支持账号收件箱的宿主与云端服务。
- 从账号菜单打开「邀请奖励」时，直接定位到积分页中的邀请奖励区域。
- 离线同步目录恢复工具按目标 Electron 配置目录检查占用；独立配置目录中的其他实例不会误挡恢复，原文件与同步记录保持不变。

- Connects the official inbox to supported desktop, web and mobile hosts. History and archives come from the current account; read, archive and delete state sync across clients, and attachment claims use the same record. Fixes the empty inbox in the new web host when the account channel was missing. Requires a host and server that support the account inbox.
- Opening Invitation rewards from the account menu now focuses the invitation section on the points page.
- The offline sync-root recovery tool checks the target Electron profile for running instances. Independent profiles no longer block recovery; original files and sync records are preserved.

## 0.10.4 — 2026-11-11

- 云端文件下载等待本机写入期间，如果同步目录的磁盘挂载或目录本身发生变化，会暂停这一轮并保留原文件与同步记录，避免写入错误目录或随后误删云端文件。
- 快速切换账号或登出后重新登录时，迟到的旧同步任务不会再切走当前目录或干扰新会话；已有笔记和各账号的同步记录继续保留。

- If a sync folder's mount or directory changes while a cloud download is waiting for a local write, that round now pauses and retains the original files and sync records, preventing writes to the wrong folder or later cloud deletions.
- After switching accounts or signing out and back in, an older sync task finishing late no longer switches away from the current folder or interferes with the new session. Existing notes and each account's sync records are retained.

## 0.10.3 — 2026-11-11

- 修复 macOS 重启或磁盘重新挂载后，同一个同步目录被误判为已替换而停止同步的问题。恢复同步时保留原有文件和同步记录，离线期间的文件改名也能继续沿用原来的同步身份。
- 目录确实被替换、丢失或无法确认身份时，会继续停下等待核对，避免把目录变化当成文件删除。

- Fixed sync stopping after a macOS restart or volume remount because the same folder was mistaken for a replacement. Existing files and sync records are retained, and files renamed while offline keep their sync identity.
- A replaced, missing or unverified folder still pauses sync for review, preventing folder changes from being treated as file deletions.

## 0.10.2 — 2026-11-09

- 网页版和手机 App 现在也能提交反馈：网页版点左侧栏下方的「反馈」，手机点右上角「⋯」里的「反馈」；也可以在命令面板里搜「反馈」，或在输入框里输入 /feedback（后面可以直接跟上要说的话）。写下遇到的问题或建议，可以选择附带诊断信息，提交后会给出反馈编号。需要 Forsion 2.14.0 之后的版本，网页版和手机 App 更新后才会出现；旧版本上没有变化。

- You can now send feedback from the web app and the phone app. On the web, click Feedback at the bottom of the left bar; on the phone, tap Feedback under the "more" button at the top right. You can also search for Feedback in the command palette or type /feedback in the message box, optionally followed by what you want to say. Describe the problem or suggestion, choose whether to attach diagnostics, and you get a ticket number once it's sent. Requires a Forsion version newer than 2.14.0; it appears after the web app and the phone app are updated, and nothing changes on older versions.

## 0.10.1 — 2026-11-09

- 设置 › 账号 › 登录与资料新增「微信剪藏助手」：先在微信里添加 Forsion 企业微信号，点「获取绑定码」，把 6 位码发给它；绑好后发给它的小红书、B 站、X 和网页链接会剪藏进你云端智库的 Plugins/wechat-helper 文件夹，其他消息按天记进日记。已绑定时显示绑定日期，可以解绑；会员档位不够时会说明，云端未开放时不显示。在设置里搜「微信」也能找到。

- Settings › Account › Sign-in & details has a new WeChat Helper section: add the Forsion WeCom account in WeChat, click Get binding code and send it the 6-digit code. Once linked, Xiaohongshu, Bilibili, X and web links you send it are clipped into Plugins/wechat-helper in your cloud vault, and other messages go into a daily note. When linked it shows the date and lets you unlink; if your plan doesn't include it you'll see a note, and it stays hidden where it isn't available. Search "WeChat" in Settings to find it.

## 0.10.0 — 2026-11-09

- Forsion Connect 发布网页时可以选「我来付」：用了 AI 的网页，访客调用 AI 的花费可以由你从额度包里出，并设每位访客每天几次、整页每天最多花多少积分；超出后按你选的方式处理。发布窗口里新增「AI」一节，只在网页用到 AI 时出现（配合 Forsion 2.14.0-beta.1）。
- 「我的网页」新增「已发布 / 收藏」两栏：上方显示额度包余额、余额不足提醒和近 30 天用量，可以直接去买；每个网页一行显示 AI 由谁付、今天用了多少，并能就地改设置；因预算用完暂停的网页可以一键「继续由我付」。网址下方显示点赞和收藏数。
- 「收藏」一栏列出你收藏的网页，可以打开、去作者主页或取消收藏。
- 背包里的额度包会写明能做什么，使用后告诉你到账了多少。
- 活动中心的红点按活动规则亮：新活动、可以领奖、快到截止时才提醒；看过的活动在你的各台设备上都算已看。活动列表会记住上次的内容，打开更快。
- 个人主页公开后，「已公开」下方直接显示可以点开的主页地址，旁边一键复制；地址暂时取不到时显示「重试」。
- 需要 Forsion 2.13.8-beta.3 或更高版本；标了 2.14.0-beta.1 的几项要新版本才出现，旧版本上照旧使用原来的发布窗口。

- Forsion Connect pages can now have you pay for visitors' AI: for a page that uses AI, its visitors' AI calls can be paid from your points pack, with a daily limit per visitor and a daily points cap for the page, and you choose what happens when it runs out. The publish dialog has a new AI section that appears only when the page uses AI (with Forsion 2.14.0-beta.1).
- My web pages has Published and Saved tabs. At the top you see your pack balance, a low-balance notice and the last 30 days of usage, with a way to buy more. Each page shows who pays for AI and today's usage, and you can change its settings in place; a page paused because its budget ran out can resume with one click. Likes and saves show under each address.
- The Saved tab lists pages you saved: open them, go to the author's page, or remove them.
- Points packs in your backpack say what they do, and using one tells you how much was added.
- The Events dot now follows each event's rules: it lights up for new events, rewards you can claim and approaching deadlines, and events you've seen count as seen on all your devices. The events list remembers what it last showed, so it opens faster.
- Once your profile is public, a link you can open now appears under Public, with a button to copy it; if the address isn't available yet, you'll see Retry.
- Requires Forsion 2.13.8-beta.3 or later. Items marked 2.14.0-beta.1 need the newer version; older versions keep using the previous publish dialog.

## 0.9.8 — 2026-11-08

- 主页可以放一张「同步」卡：一眼看到是否已同步、正在传多少、哪些文件没传成或有冲突，点一下打开蓬洲云。在主页的 Space 收纳面板「插件」组里找「同步」，点一下放上去。配合 Forsion 2.13.8-beta.4。
- Agent 同步改成逐个选：蓬洲云同步页的 Agents 一组里每个 Agent 一行，想同步哪个就打开哪个，新建的 Agent 默认不同步；卜算子暂不开放同步，Historian 的临时文件和备份只留在本机。别的设备上有、这台没有的 Agent 也会列出来，打开就拉下来。
- 第一次打开一个云端已有、且和这台不一样的 Agent 时，只问一次：「合在一起」「以云端为准」或「以这台为准」，被换下的那份放进本机回收或云端存档，不会丢。
- 老账号之前跟着总开关同步的 Agent 会先停下，云端那份存进「我的云盘 › 存档」，只读、能下载；同步页顶上有说明，点「打开存档」直接过去，想继续同步的再逐个打开。
- 同步页里「改这台电脑的名字」不能再和别的设备重名；Agent 记忆可以标明只对哪台电脑或哪个系统成立（配合 Forsion 2.13.8-beta.4）。
- 云同步更省、更稳：没改动时几乎不读文件、不发请求；刚改过的文件等你停手几秒再上传，切走窗口、合盖或退出时立即推上去（配合 Forsion 2.13.8-beta.4）。换账号、改名失败或网络中断后，本机已有的文件都保留，恢复后接着对账。
- 设置 › 账号新增「主页地址」，点「改地址」就能换个人主页的地址：有免费次数时直接改，之后用地址改名卡，没有卡可以用积分买一张。背包里的地址改名卡可以直接「去改地址」。
- 蓬洲云「我的云盘」下新增「商店投稿」：列出你投稿的插件占了多少空间、审核状态；从 GitHub / npm 拉取的不算空间。要腾空间去「商店 › 我的投稿」删条目。
- 上传、下载进度卡浮在整个蓬洲云 Space 的右下角，在各页之间切换时一直在；切到别的 Space 时先藏起来，传输照常进行（配合 Forsion 2.13.8-beta.4）。
- 原地加入「造物」的项目也能发布到 Forsion Connect，不用再复制进 Project 文件夹（配合 Forsion 2.13.8-beta.4）。
- 会员页和积分商店里的方案名、说明跟随界面语言显示。
- 「帮助改进 Forsion」只在登录 Forsion 账号时发送，没登录不发送任何数据；升级时没登录、也没自己改过开关的用户会被改成关。隐私页不再罗列收集项，改为链接到隐私政策。忽略 Muse 卡片或忘记一条记忆时选的理由，也只按次数统计。
- 上传的诊断数据里加了云同步状态（规则开在哪几类、最近几轮的计数和报错原因，路径会遮掉），方便排查同步问题。
- 在记忆面板或 Muse 卡片上勾选「附上这条原文，随账号发给 Forsion」后，如果中途换了账号，原文不会再发到另一个账号下。
- 需要 Forsion 2.13.8-beta.3 或更高版本；标了 2.13.8-beta.4 的几项要新版本才出现，旧版本上其余功能照常。

- Home can hold a Sync card: see at a glance whether everything is synced, how much is uploading, and which files failed or conflict; click it to open Penzor Cloud. Find Sync in the Plugins group of the Space organizer on Home and click to add it. Needs Forsion 2.13.8-beta.4.
- Agents now sync one by one: the Agents group on the Penzor Cloud sync page has a row per agent; turn on the ones you want, and new agents start off. Muse can't sync yet, and Historian's temporary files and backups stay on the device. Agents that exist on another device but not this one are listed too, and turning one on pulls it down.
- The first time you turn on an agent that already has a different copy in the cloud, you're asked once: Merge, Use the cloud copy, or Keep this computer's. The copy that loses goes to the local trash or the cloud archive, so nothing is lost.
- On older accounts, agents that synced with the old all-agents switch stop first, and their cloud copy goes to My drive › Archive, read-only and downloadable. A note at the top of the sync page explains this, Open archive takes you there, and you turn agents back on one by one.
- Rename this computer on the sync page no longer accepts a name another device uses, and agent memory can say which computer or system an entry applies to (with Forsion 2.13.8-beta.4).
- Leaner, steadier cloud sync: when nothing changed it barely reads files or sends requests; a file you just edited uploads a few seconds after you stop, and right away when you switch windows, close the lid or quit (with Forsion 2.13.8-beta.4). After an account switch, a failed rename or a dropped connection, files on this device are kept and reconciled once things recover.
- Settings › Account has a new Page address row: Change it to move your profile page. A free change is used first if you have one, after that it takes an address rename card, and you can buy one with points if you have none. Rename cards in your backpack have a Change address shortcut.
- Penzor Cloud's My drive has a new Store submissions item: how much space your submitted plugins take and their review status. Packages pulled from GitHub or npm don't count. To free space, delete items under Store › My submissions.
- The upload and download card now floats in the bottom-right corner of the whole Penzor Cloud Space and stays while you move between its pages. It hides while another Space is open; transfers keep running (with Forsion 2.13.8-beta.4).
- Projects added to Creations in place can be published to Forsion Connect without copying them into the Project folder first (with Forsion 2.13.8-beta.4).
- Plan names and descriptions on the membership and points store pages follow the interface language.
- Help improve Forsion only sends while you're signed in to a Forsion account, and nothing is sent while signed out. If you were signed out at upgrade and never changed the switch yourself, it's turned off. The privacy page no longer lists what's collected and links to the Privacy Policy instead. The reason you pick when dismissing a Muse card or forgetting a memory is counted too, as a count only.
- Uploaded diagnostics now include cloud sync status (which categories are on, counts and error reasons from recent rounds, with paths masked) to help track down sync problems.
- After ticking "Also send this text to Forsion with my account" in the memory panel or on a Muse card, the text is no longer sent under a different account if you switched accounts in between.
- Needs Forsion 2.13.8-beta.3 or later; the items marked 2.13.8-beta.4 appear only on the newer version, and everything else works as before on older ones.

## 0.9.7 — 2026-11-02

- 活动中心的礼物图标常驻 Ribbon，没有进行中的活动时点开也能看到已结束的活动和空态；红点照旧只在有可领奖励或新活动时亮。配合 Forsion 新版本，它排在「商店」下面、原来明暗切换的位置，明暗切换挪到最后。

- The Events gift icon now stays on the Ribbon. With nothing running, it opens to past events and an empty state; the red dot still lights only when a reward or new event is waiting. With the next Forsion release it sits right below Store, where the light/dark switch used to be, and the switch moves to the end.

## 0.9.6 — 2026-11-02

- 新增活动中心：签到、任务、小游戏和公告都在一个面板里，左边选活动，右边看奖励、进度和结束时间，可以直接签到、领取。Ribbon 上的礼物图标有可领奖励或新活动时亮红点，当前没有活动时不显示；⌘K 搜「活动」随时能打开。手机上是一页完整列表。
- 活动由官方在后台发布，同一时间可以有多个，奖励发到账户或背包。
- Amadeus 协作共享：可以把关联的页面一起共享，邀请链接直接打开文件；新增「我共享的」和共享与发布总览。走出页面目录的相对引用也能按共享绑定找回文件。
- 云同步更稳：单个二进制文件上传、下载失败或卡住时不再拖住笔记同步，也不会让引擎显示离线；1 MiB 以上文件的合并基线会保留，删掉的行不再回来。
- 需要 Forsion 2.13.8-beta.3 或更高版本。

- New Events center: check-ins, tasks, mini games and announcements in one panel. Pick an event on the left and see its rewards, progress and end time on the right, then check in or claim right there. The gift icon on the Ribbon shows a red dot when a reward or new event is waiting, and stays hidden when nothing is running; search "Events" in ⌘K to open it any time. On phones it is a full-page list.
- Events are published by Forsion from the admin console. Several can run at once, and rewards go to your account or backpack.
- Amadeus sharing: share linked pages together, and invite links open the file directly. New Shared by me and a sharing and publishing overview. Relative references that leave a page's folder now find their files through the share binding.
- Steadier cloud sync: a failed or stuck upload or download of one binary file no longer holds up note sync or takes the engine offline. Merge baselines for files over 1 MiB are kept, so deleted rows stay deleted.
- Needs Forsion 2.13.8-beta.3 or later.

## 0.9.5 — 2026-10-27

- Tangu 可以替你提交自己投稿的商店更新：说一句「我在 GitHub 上发了 v1.1.0，把商店更新也提交了」，Tangu 先检查读到的新版本，再弹审批卡请你确认，确认后送审。GitHub / npm 来源可申请新版本，任何来源都可以改商店信息；ZIP 包仍在投稿页上传。每次提交都要你本人批准，自动任务里不会提交。
- 提交后对话里显示一张「商店更新」卡片：待审核、已通过或没通过（附审核意见），打开时读一次最新状态；可直接跳到投稿页里的这一条。
- 需要支持官方插件云端接缝的 Tangu 引擎；旧引擎上这两个工具不出现，其余功能不受影响。

- Tangu can submit Store updates for your own submissions: say "I published v1.1.0 on GitHub, submit the Store update" and Tangu checks the new version it finds, asks you on an approval card, then sends it to review. GitHub and npm items can request a new version, and any item can change its store info; ZIP packages are still uploaded on the Submissions page. You approve every submission yourself, and automated runs never submit.
- After submitting, the chat shows a Store update card: in review, approved, or not approved (with the review note). It reads the latest state each time it is shown and can open that item on the Submissions page.
- Needs a Tangu engine that offers the official-plugin cloud seam; on older engines the two tools do not appear and everything else works as before.

## 0.9.4 — 2026-10-24

- 插件投稿改成左右分栏：左边是你的投稿，右边看版本、商店信息和历史。上传 ZIP 后先由云端检查并列出读到的版本、图标和说明，确认后再提交；GitHub / npm 来源可以检查上游新版本并申请更新；只改商店信息不用重新上传包。版本号一律从包里或上游读取，不用手填。
- 新增「我的网页」：列出发布到 Forsion Connect 的网页，可打开、复制链接、下架，也可以申请上架商店、撤回或在被拒后重新申请。
- 蓬洲云同步页改成按类别开关：笔记、Agents 与记忆、我的资料、插件各一行，每行可选同步到所有设备、只在这台电脑或只和某台设备同步；改动先预览再确认，规则表移到「更多 › 高级」。侧栏、概览与各内容页同步整理，文件夹显示合计大小。
- 蓬洲云换上新的「祥云」图标与页头字标。

- Plugin submissions now use a split view: your submissions on the left; version, store details and history on the right. A ZIP is checked by the cloud first, showing the version, icon and notes it found, before you submit it; GitHub and npm items can check upstream for a new version and request an update; editing store details no longer needs a new package. Versions always come from the package or upstream, never typed in.
- New My web pages: lists the pages you published to Forsion Connect, with open, copy link and take down, plus applying for a store listing, withdrawing, or reapplying after a rejection.
- The Penzor Cloud sync page is now a list of categories: Notes, Agents & memory, About me and Plugins each have a switch and a choice of all devices, this computer only, or one other device. Changes are previewed before you confirm, and the rule table moves to More › Advanced. The sidebar, overview and content pages are reorganized to match, and folders show their total size.
- Penzor Cloud has a new ruyi-cloud icon and page-header wordmark.

## 0.9.3 — 2026-10-22

- 原生手机复用账号、个人主页、会员与积分商店、公告和蓬洲云，直接读取当前账号已有的云端资料。手机上传交文件选择器，下载通过宿主保存，付款与外部链接沿用系统浏览器；本机同步开关和诊断仅在桌面提供。需要带 `mobileHostApi: 1` 接缝的手机宿主。
- Web 与手机登出或切换账号后，立即取消旧传输并清除队列与文件夹缓存；延迟返回的资料、上传额度与登录交接不再影响新账号。
- 桌面同步支持按文件夹选择范围、方向与默认或设备专属云端位置；启用和修改规则前先预览，传输中可查看进度、暂停和重试。重命名保留同步身份，冲突保留待处理版本；旧桌面仍使用原有同步页。

- Native mobile now reuses the account/profile pages, membership and points store, announcements, and Penzor Cloud with the signed-in account’s existing cloud data. Uploads use the file picker, downloads are saved by the host, and payments/external links use the system browser. Local sync controls and diagnostics remain desktop-only. Requires a mobile host supporting `mobileHostApi: 1`.
- Signing out or switching accounts on Web/mobile cancels old transfers and clears the queue and folder cache. Late account responses, upload quota checks and browser handoffs cannot affect the new account.
- Desktop sync supports per-folder scope, direction and default or device-specific cloud destinations. Preview changes before enabling or editing rules, and follow, pause or retry transfers. Renames retain sync identity and unresolved versions stay available; older desktop hosts keep the original sync page.

## 0.9.2 — 2026-10-21

- 「我的云盘」统一按来源显示笔记库、Agents、我的资料、应用、插件数据和上传文件。同步与应用维护的内容只读，上传文件仍可整理。
- 统一用量包含现存文件与回收站，历史版本单列；通知与宽限状态由云端返回。云端尚未升级时保留原有文件访问，用量未知不会显示成零。
- Agents 与插件数据的同步页补充上次同步、失败、冲突副本与待上传状态；额度不足不再误报成单个文件过大。需要 Forsion Desktop 2.13.5 或更新，新增同步反馈随宿主能力显示。

- My drive groups cloud content by source: note vaults, Agents, your profile, apps, plugin data and uploaded files. Content maintained by sync or apps is read-only; uploaded files remain editable.
- Unified usage includes current files and trash, with history shown separately. Notices and grace periods follow the server response. Existing file access remains available before the server upgrade, and unknown usage is never shown as zero.
- Sync now shows the last run, failures, conflict copies and pending plugin changes when supported by the host. Storage quota errors no longer appear as a single-file size limit. Requires Forsion Desktop 2.13.5 or later.

## 0.9.1 — 2026-10-20

- **网页版也有了**：在服务器的网页版 Forsion（Unit 的网页主入口）里登录后，设置里的「Forsion 云端」有账号、个人主页、安全、额度与积分、用量记录、背包、插件投稿和反馈这几页，商店里有会员、积分、物品三页和投稿，公告照常弹。网页版装不了插件，所以商店里不列插件目录。买会员、充积分、打开个人中心会在浏览器新标签页里打开，不用再登录一次。
- 「蓬洲云」在网页版上也能用：概览、各本账、我的云盘和回收站都在，能重命名、移动、移到回收站、恢复、永久删除、新建文件夹，也能上传和下载。上传可以点「上传」选文件或整个文件夹，也能直接拖进文件表；下载会存进浏览器的下载，多选下载不另建文件夹。同样是各自同时 3 个、能暂停、继续、取消、重试，单个文件最大 50 MB、空间不够整批不开始。网页上的上传看不到进度，传完一下到头；关掉或刷新页面时还有没传完的，浏览器会先问一次。导出和智库同步的文件如果浏览器读不到，会在新标签页里打开，浏览器拦了弹出窗口就允许后再试一次。诊断上传只在桌面端。
- 看别的设备的设备页上照旧不出现这些页（那边登录的不是你这个账号）；网页版不跑笔记同步。
- 需要带同一批接缝的网页版 Forsion；更早的网页版上什么都不变。
- 修复：把文件夹拖进「我的云盘」、还没展开完就切到别的文件夹时，文件不再传进后来那个；刚点暂停或取消的下载不会再接着开始。

- **Now on the web too**: after you sign in to Forsion on the web (a server Unit’s main web page), Forsion Cloud in Settings has your account, profile, security, quota & points, usage, backpack, submissions and feedback, the store has the Membership, Points and Items pages plus submissions, and announcements show up as usual. The web version can’t install plugins, so the store doesn’t list them there. Buying membership, topping up points and opening the account center open in a new browser tab, already signed in.
- Penzor Cloud works on the web too: the overview, every ledger, My drive and Trash are there, and you can rename, move, move to trash, restore, delete permanently, create folders, upload and download. Upload files or a whole folder with Upload, or drag them into the file table; downloads go to your browser’s downloads, and a multi-file download doesn’t make a folder. Transfers work as on the desktop: 3 at a time each way, with pause, resume, cancel and retry, a 50 MB limit per file, and a batch that doesn’t fit your space doesn’t start. Uploads on the web don’t show progress and jump to done when finished. If you close or refresh the page while something is still transferring, the browser asks first. If the browser can’t read an export or a synced file directly, it opens in a new tab; if pop-ups are blocked, allow them and try again. Diagnostics upload is still desktop-only.
- Device pages, where you view another device, still don’t show these pages (that device isn’t signed in as you), and the web version doesn’t run note sync.
- Needs a web version of Forsion with the matching hooks; older web versions are unchanged.
- Fixed: dropping a folder into My drive and switching folders before it finished expanding no longer uploads into the folder you switched to, and a download you just paused or cancelled no longer starts anyway.

## 0.9.0 — 2026-10-20

- 这一版需要 Forsion 桌面端 2.13.5 或更新；更早的桌面端继续用自带的版本，升级桌面端后再换上。
- This version needs Forsion Desktop 2.13.5 or later. Older desktops keep the version they came with and switch after the desktop is updated.

- 新增 **「蓬洲云」Space**：在桌面端看和管理你存在 Forsion 云端的东西。打开先是概览：一共存了多少、按账分段的条、四张账卡（智库同步、Amadeus Cloud、应用文件、导出；有上限的两本各画各的条，用到 90% 变警示色）和占用最多的文件。左栏是位置树，点任一个库、应用、导出或回收站，主区换成文件表、右栏出详情。
- 能做的事按账分：应用文件可以下载、重命名、移动、移到回收站、恢复、永久删除、恢复历史版本；导出可以下载、重命名、删除；智库同步的库和 Amadeus Cloud 只看和下载（在这里删一个同步库的文件，每台设备都会跟着删）。下载存进「下载」文件夹。远程同步写入时带上设备名，蓬洲云里同步库的文件能看到是哪台写的。
- 左栏第一行是 **「同步」**：智库、Agents 与记忆、插件数据三项同步的开关、状态和在同步的设备都在这一页；展开智库那一行能看同步计划、方向、没传的文件和云端位置。另一台电脑登录、云端已经有一份智库时，就在这里选「合并两边」「用云端那份」（先就地确认一次，这台不一样的文件会先挪进旁边的备份文件夹）或「这台先不同步智库」；超出额度也在这里说清楚，放不下的文件留在本机，不删。
- 没开同步或有事等你决定时，打开蓬洲云先落在同步页；有事等你决定或上次没同步成功时，Ribbon 上的蓬洲云图标挂一个点；智库在同步或有文件在传时，图标挂进度环（传文件时以传文件为准）。
- 蓬洲云也能当网盘用：左栏有 **「我的云盘」**，工具条有「上传」（下拉里还能上传整个文件夹，云端照原样建好一层层）和「新建文件夹」，文件也能从访达直接拖进文件表，拖到某个文件夹那一行上就传进那个文件夹。我的云盘算在应用文件的 10 GB 里，重名自动改成「名字 (1)」，单个文件这一版最大 50 MB；空间不够时整批不开始，告诉你还差多少。
- 上传和下载都在后台排队（各自同时 3 个），切到别的 Space 也不停。正在传进当前文件夹的文件直接出现在表里、带进度；所有传输汇总在主区右下角的一张浮动卡里：每一项的进度、速度、剩余时间，能暂停、继续、取消、重试，下载完能「在文件夹中显示」。不碰它 10 秒收成一颗胶囊，全部传完 4 秒后自己消失，有没传完的一直留着。不在蓬洲云时传完或失败会弹一句。退出 Forsion 时还有在传的会问一次。暂停后继续、失败重试都是从头传。
- 多选：⌘ 点加选、⇧ 点连选、⌘A 全选，工具条换成批量条。应用文件里能批量下载、移动、移到回收站；智库同步的库和 Amadeus Cloud 里能批量下载。一次下载多个文件会放进「下载」里的「蓬洲云 日期」文件夹。
- 需要带同一批接缝的 Forsion 桌面端和服务端；手机和网页版这一轮没有。「同步」这一行、图标上的点和进度环、退出确认、「我的云盘」的图标要带对应接缝的桌面端，更早的版本上没有这几样，别的照常。

- New **Penzor Cloud Space**: see and manage what you keep in Forsion Cloud from the desktop app. It opens on an overview: how much you store, a bar split by ledger, four cards (Vault sync, Amadeus Cloud, App files, Exports; the two with a limit each get their own bar, which turns to a warning color at 90%) and your largest files. The left panel is a tree of places; pick a vault, an app, Exports or Trash and the main area becomes a file table with details on the right.
- What you can do depends on the ledger: app files can be downloaded, renamed, moved, moved to trash, restored, deleted permanently or rolled back to an earlier version; exports can be downloaded, renamed and deleted; synced vaults and Amadeus Cloud are view and download only (deleting a synced file here would delete it on every device). Downloads go to your Downloads folder. Remote sync now sends the device name with each write, so Penzor Cloud can show which device wrote a synced file.
- The first row in the left panel is **Sync**: switches, status and syncing devices for your vault, Agents & memory and plugin data, all on one page. Expand the vault row to see its schedule, direction, files that weren’t uploaded and where it lives in the cloud. When you sign in on another computer and the cloud already has a vault, you choose here: merge both, use the cloud copy (confirmed once in place; this computer’s differing files move to a backup folder first) or don’t sync notes on this computer yet. Going over the limit is explained here too; files that don’t fit stay on this computer and nothing is deleted.
- If nothing is syncing or something needs your decision, Penzor Cloud opens on the Sync page. Its Ribbon icon shows a dot when something needs your decision or the last sync failed, and a progress ring while the vault syncs or files transfer (file transfers take precedence).
- Penzor Cloud also works as a drive: **My drive** sits in the left panel, the toolbar has Upload (its menu also uploads a whole folder, recreated level by level in the cloud) and New folder, and you can drag files straight from Finder into the file table, or onto a folder's row to put them in that folder. My drive counts toward the 10 GB for app files. Duplicate names become "name (1)", files are limited to 50 MB each for now, and if a batch won't fit, none of it starts and you're told how much space is missing.
- Uploads and downloads queue in the background (three at a time in each direction) and keep going when you switch Spaces. Files on their way into the folder you're viewing show up in the table with their progress, and every transfer is listed in a floating card at the bottom right of the main area: progress, speed and time left for each, with pause, resume, cancel and retry, plus Show in folder for finished downloads. Left alone for 10 seconds it shrinks to a pill; once everything is done it disappears after 4 seconds, and it stays while anything didn't finish. If you're elsewhere you get a short notice when transfers finish or fail. Quitting Forsion while something is still transferring asks first. Resuming after a pause and retrying both start the file over.
- Multiple selection: ⌘-click to add, ⇧-click for a range, ⌘A for everything; the toolbar turns into a batch bar. App files can be downloaded, moved or moved to trash in bulk; synced vaults and Amadeus Cloud can be downloaded in bulk. Downloading several files at once puts them in a "Penzor Cloud <date>" folder inside Downloads.
- Needs a Forsion desktop app and server with the matching hooks; not on phones or the web yet. The Sync row, the dot and progress ring on the icon, the quit prompt and the My drive icon need a desktop app with the matching hooks; on older versions those are missing and everything else works.

- 新增 **「使用指南」Space**：Forsion 的说明书，排在 Space 列表末尾（图标是一本书）。左栏按等级列出章节（Lv.1 初来乍到 → Lv.4 融会贯通，外加「新版本」一组），正文是只读的 Amadeus 页，下面是本章任务。每章导语下面有一张示意图，画出这一章要找的地方在界面哪儿（1–3 处，带编号，正文里的 ①②③ 对得上），跟着当前亮暗和主题色走。本级任务做完，下一级解锁；任务就是你平时的操作（发消息、建笔记、换主题……），以前做过的直接算数。
- 每项任务都有 **「带我去」**：切到对应的 Space，在真界面上圈住要点的那一处，旁边一张小卡写这一步做什么（「第 n 步，共 m 步」），你自己点；做完这一步圈自动挪到下一步。不压暗屏幕、不挡点击，「知道了」或 Esc 收起，「不再提示」等于关掉指南「···」菜单里的「现场指引」（缺省开）；目标找不到时直接打开对应功能。这一章的任务同时跟到那个 Space 的右栏（伴读），做完一项就地打勾，整章做完伴读自己收起。手机和网页上做不了的任务写着「在电脑上做」，不挡升级。
- 右栏是本级进度和下一级，**「问 Tangu」** 就是 Tangu 的对话本身：同一个输入框、消息、模型和附件，本章内容挂在输入框上方当引用，问完不用离开指南；这条对话一直接着用，下次打开历史还在，Tangu 的会话列表里也看得到。换一章，引用跟着换。用过一阵的话，右上角「···」里可以全部解锁，也能关掉「使用指南提醒」。
- 每升一级，收件箱来一封「接下来试试这几件事」，信下面就是那几章的任务，可以直接「带我去」；装上带「新版本」章节的新版本后，也会来一封这个版本可以体验的清单。收件箱里同时只留一封未读的指南信。等级只管解锁章节，Forsion 现有的成就照常算。
- 需要带同一批接缝的 Forsion 桌面端；更早的桌面端上不出现这个 Space。现场圈注和指南里的对话要带对应接缝的桌面端，不够新时「带我去」直接打开对应功能，「问 Tangu」去 Tangu 里开一条带上本章内容的新对话。

- New **Guide Space**: a manual for Forsion, at the end of your Space list (the book icon). The left panel lists chapters by level (Lv.1 Getting started to Lv.4 Going further, plus a What's new group), the page itself is a read-only Amadeus page, and the chapter's tasks sit below it. Every chapter has a diagram under its intro showing where in the app the things it covers live (one to three numbered spots that match the ①②③ in the text), drawn in your current light/dark mode and accent color. Finish a level's tasks to unlock the next one. Tasks are things you do anyway (send a message, create a note, change the theme), and whatever you've already done counts.
- Every task has **Take me there**: it switches to the right Space and rings the spot to click on the actual screen, with a small card saying what this step does ("Step n of m"), and you click it yourself; once that step is done the ring moves to the next. Nothing is dimmed or blocked. Got it or Esc dismisses it, and Don't show again turns off On-screen hints in the guide's "···" menu (on by default). If the spot can't be found, it opens the feature directly. The chapter's tasks follow you into that Space's right panel, each one ticks off as you finish it, and the panel closes itself once the chapter is done. Tasks that can't be done on a phone or in the browser say "Do it on your computer" and don't hold you back.
- The right panel shows the level's progress and the next level, and **Ask Tangu** there is Tangu's own chat: the same input, messages, models and attachments, with the current chapter attached above the input as a quote, so you can ask without leaving the guide. It keeps using one conversation, so your history is there next time, and it also shows up in Tangu's chat list. Switch chapters and the quote follows. If you've been around a while, unlock everything from the ··· menu; the same menu turns Guide reminders off.
- Each new level brings a letter to your inbox, "try these next", with that level's tasks right under it and a Take me there button on each. After an update that adds What's new chapters you get a list of what to try in that version. Only one unread guide letter stays in your inbox at a time. Levels only unlock chapters; Forsion's existing achievements count as usual.
- Needs a Forsion desktop app with the matching hooks; on older versions the Space doesn't appear. On-screen hints and the chat in the guide need a desktop app with the matching hooks; on older versions Take me there opens the feature directly and Ask Tangu opens a new chat in Tangu with the chapter attached.

- **笔记云同步**：云端笔记库里每个「同步库」文件夹现在会记下是哪几台设备在同步它。桌面端 Cloud 侧的同步库分区头会显示来源设备（本机写「本机」），要比 2.13.4 更新的桌面端才显示。以前开启同步的库会在下次启动时自动补上本机。
- 一台设备把某个库的同步全部关掉后，会从记录里摘掉自己；没有设备在同步了，Cloud 侧就不再把它显示成同步库分区。关闭时没联网的，下次打开 Forsion 时自动补做。
- 桌面端 Cloud 侧可以把根文件夹「设为同步库分区」，或把旧版留下的分区取消掉（需要新版桌面端）。
- 笔记云同步下载附件（比如图片）时，云端存储那边的拒绝访问（链接过期、文件缺失）不再被当成登录失效、让同步停下等你重新登录，而是稍后自动重试。

- **Note cloud sync**: each synced vault folder in your cloud notes now records which devices are syncing it. On the desktop, the synced vault sections on the Cloud side show the device it comes from ("This device" for this one); this needs a desktop app newer than 2.13.4. Vaults you turned sync on for earlier add this device automatically on the next launch.
- When a device turns sync off for everything in a vault, it removes itself from that record; once no device is syncing it, the Cloud side stops showing it as a synced vault section. If the device was offline at the time, this happens the next time Forsion starts.
- On the desktop's Cloud side you can mark a top-level folder as a synced vault section, or remove a section left behind by older versions (needs the new desktop app).
- When note cloud sync downloads an attachment (an image, say) and cloud storage refuses it (an expired link or a missing file), sync no longer takes that as a sign-in failure and stops until you sign in again; it retries a little later instead.

- 「设置 → Forsion 云端」重新分组：左栏收成账号、会员与额度、背包、插件投稿、帮助与诊断几项；账号下分个人主页、账号资料与安全，会员与额度下分积分与邀请、用量记录，帮助与诊断下分反馈与诊断数据。各页能在设置搜索里按关键词找到。分组要比 2.13.4 更新的桌面端；2.13.4 及更早上这些页面照旧平铺在左栏。
- 插件投稿页新增详细描述、标签（最多 8 个）、最低 / 最高 Forsion 版本和支持的端；ZIP 投稿会自动读取清单里的版本要求，手填的值要和清单一致。投稿后自动分配唯一插件 ID，名字可以和别的插件重复，更新沿用同一个 ID。
- 公告弹窗改成排队出：Forsion 自己的协议更新提示和更新内容（What's new）在前，同一时间只露一张，前一张关了下一张才出；全屏引导开着时先不弹。要带同一批接缝的桌面端，更早的版本上照旧直接弹。

- Settings → Forsion Cloud is regrouped: the sidebar now has Account, Membership & quota, Backpack, Submissions, and Help & diagnostics. Account holds Profile, Account details and Security; Membership & quota holds Points & invites and Usage; Help & diagnostics holds Feedback and Diagnostic data. Each page can be found by keyword in Settings search. Grouping needs a desktop app newer than 2.13.4; on 2.13.4 and earlier the pages stay listed one by one in the sidebar.
- The Submissions page adds a detailed description, tags (up to 8), minimum and maximum Forsion versions, and supported platforms. ZIP submissions read the version requirements from the manifest, and values you type must match it. Each submission gets a unique plugin ID, names may repeat, and updates keep the same ID.
- Announcements now wait their turn: Forsion's own terms-update notice and What's new come first, only one shows at a time, and the next appears once the previous one is closed; nothing pops up while full-screen onboarding is open. Needs a desktop app with the matching hooks; older versions show announcements right away as before.

## 0.8.3 — 2026-10-13

- 「设置 → Forsion 云端」新增**插件投稿**页：查看自己投稿的审核状态与原因（待审、已上架、已驳回），用 GitHub 仓库、npm 包或 ZIP 投稿，给 ZIP 投稿提交新版本送审。同一页也出现在商店左栏的「投稿」里。
- **诊断数据**（「账号」页里的可选上传，默认关闭）补了几样，方便 Forsion 团队定位问题：最近 7 天每次运行的状态和报错原因、模型调用与工具的用量和耗时，这台电脑的内存与磁盘余量，以及引擎最近的运行日志（引擎日志要比 2.13.3 更新的桌面端才有）。这几样里没有对话内容，跟着「上传诊断数据」的总开关走。
- 诊断数据新增一个开关「**包含 Agent 的人设、记忆与进化记录**」：每个 Agent 的人设（包括配置里的描述和开发者指令）、记忆和还没整理的记忆候选、进化记录、写给你的协作说明、最近 7 天的日志和记忆整理记录，项目记忆，团队的设定，以及你的用户画像。这些是你写的设定和 Agent 从对话里记下的事实，常见格式的密钥会遮掉，其余原样上传；不打开这个开关，这些文件不会被读取。已经开着上传的账号升级后这一项是关的；新打开上传时它默认开着，可以先关掉再打开上传。卡片上原来那句「不会上传 Agent 的记忆与人设」相应改了。
- 修复：云端托管模型的编号在诊断数据里被当成密钥遮掉，看不出用的是哪个模型。
- 修复：诊断数据里 Agent 与团队配置的提纲，在手动改过的配置文件上可能把别处的一小段文字带上去。现在按配置文件的语法解析，只带选项和开关的值；引擎不认识的键名只记长度。

- **Submissions** is a new page under Settings → Forsion Cloud. See the review status and reasons for what you have submitted (pending, listed, rejected), submit from a GitHub repository, an npm package or a ZIP, and send a new version of a ZIP submission for review. The same page also appears under Submit in the Store.
- **Diagnostic data** (the optional upload on the Account page, off by default) now covers a few more things that help the Forsion team track problems down: each run from the last 7 days with its status and error reason, usage and timing of model calls and tools, this computer's free memory and disk space, and the engine's recent log output (engine logs need a desktop app newer than 2.13.3). None of these contain conversation text, and they follow the main "Upload diagnostic data" switch.
- Diagnostic data has a new switch, **Include agent personas, memory and evolution records**: each agent's persona (including the description and developer instructions in its configuration), its memory and the memory candidates it hasn't consolidated yet, its evolution record, its collaboration notes for you, the last 7 days of its logs and memory-consolidation activity, project memory, your teams' charters, and your user profile. These are instructions you wrote and facts your agents noted from conversations; keys in common formats are masked and everything else is uploaded as is. Unless this switch is on, those files are never read. If uploads were already on, this starts off after the update; when you turn uploads on for the first time it starts on, and you can turn it off first. The line on the card that said agent memory and personas are never uploaded has been changed to match.
- Fixed: the id of a cloud-hosted model was masked as if it were a key, so diagnostic data didn't show which model was in use.
- Fixed: the outline of agent and team configuration in diagnostic data could pick up a short piece of text from elsewhere in a hand-edited configuration file. The file is now parsed by its syntax and only option and switch values are kept; key names the engine doesn't know are recorded by length only.

## 0.8.2 — 2026-10-11

- 「设置 → Forsion 云端」新增**个人主页**：和网页个人中心是同一张主页，现在在桌面端也能看、能改。可以就地改头像、昵称、简介和链接，选哪几件作品放上去；在「装饰」里换封面和头像框，调整各模块的顺序、显示与否、是否给访客看，给公开页选配色和明暗。
- 可以把主页公开或设回私有。公开前会列出每一块给不给访客看；邮箱、手机号、会员到期日、积分和额度不会出现在主页上。公开后可以复制地址，或在浏览器里查看公开页。
- 在桌面端，主页跟 Forsion 当前的主题走（主题色、背景色、明暗）。装饰里的「公开页的配色」「公开页的明暗」只管访客在公开页上看到的。
- 需要 Forsion 云端 2.3.37 或更新版本；更早的云端上这一页只显示一句说明。

- **Profile** is a new page under Settings → Forsion Cloud. It is the same profile as in the web account center, and you can now view and edit it on the desktop. Change your photo, nickname, bio and links in place and choose which works to feature. Under Decorate you can change the cover and avatar frame, pick the public page's color scheme and appearance, and reorder sections, show or hide them, and decide whether visitors see them.
- You can make your profile public or private again. Before it goes public you see what visitors will get, section by section; your email, phone number, membership expiry, points and quota never appear on your profile. Once it's public you can copy its address or view the public page in your browser.
- On the desktop your profile follows Forsion's current theme (theme color, background and light or dark appearance). "Public page color scheme" and "Public page appearance" under Decorate only set what visitors see on the public page.
- Requires Forsion Cloud 2.3.37 or later. On earlier versions the page shows a short note instead.

## 0.8.1 — 2026-10-06

- 商店左栏新增「会员与积分」分区，三页：**会员**（当前档位与积分余额；按月付 / 季付 / 年付选档位，付款在浏览器的支付页完成，回到应用后自动刷新）、**积分**（积分包，付款后即时到账）、**物品**（用积分兑换，在应用内直接完成，兑换后进背包）。需要带商店页面位的 Forsion 桌面版；更老的桌面版上不出现这个分区，其余功能不受影响。
- 兑换没收到结果时不会自动重试，会提示先到背包看有没有到账。
- 「应用市场 / 插件商店」的称呼统一成「商店」。

- The store sidebar has a new **Membership & points** section with three pages. **Membership** shows your current plan and points balance and lets you pick a plan billed monthly, quarterly or yearly; payment happens on the payment page in your browser and the app refreshes when you come back. **Points** lists point packs, credited as soon as you pay. **Items** lets you redeem items with points inside the app; redeemed items go to your backpack. This needs a Forsion desktop version that provides store pages. On older desktop versions the section doesn't appear and everything else works as before.
- If a redemption gets no response, the app doesn't retry on its own. It asks you to check your backpack first.
- “Market” and “plugin store” are now called the store everywhere.

## 0.8.0 — 2026-10-05

- 新增「诊断数据」：在「设置 → Forsion 云端 → 账号」里可以打开，默认关闭。打开后，这台电脑会定期上传一份 Forsion 信息快照到你的 Forsion 账号，帮助我们排查问题、改进产品。多久上传一次由 Forsion 团队设定，默认每天一次，也可能只在需要时采集。快照包含应用与系统版本、模型与语音的选择、后台 Agent 与插件设置里的开关和数值、MCP 服务与消息通道的名字、Agent 与团队的配置（提示词只记长度，不带内容），以及已安装的插件、技能、主题和 Space 的名字。
- 两项带个人内容的数据各有一个开关，打开上传之前就能先关：会话内容（这台电脑上的对话文字、Agent 的思考过程和用到的工具名，包括团队成员、讨论、委派在后台做的那部分；工具读写的内容和附件本身不带，消息里出现的文件名、Agent 在回复里复述的笔记或文件内容会在其中；常见格式的密钥会遮掉，其余原样上传），以及活动日志（含对话开头的几十个字和笔记文件名）。这两项每次只上传还没上传过的部分，最多往前 7 天。
- 保存在这台电脑上的登录凭据与 API 密钥、笔记文件、Agent 的记忆与人设、插件数据不会上传。
- 云端保留每台电脑最近 14 天的快照；关闭后不再上传。

- Diagnostic data: you can now turn this on under Settings → Forsion Cloud → Account. It is off by default. When it's on, this computer periodically uploads a snapshot of its Forsion setup to your Forsion account to help us troubleshoot problems and improve the product. The Forsion team sets how often: once a day by default, or only when a snapshot is needed. The snapshot covers app and system versions, your model and voice choices, the switches and numeric values in background agent and plugin settings, the names of MCP servers and message channels, agent and team configuration (prompts are recorded by length only, never their text), and the names of installed plugins, skills, themes and Spaces.
- Two kinds of personal content each have their own switch, which you can turn off before you turn uploads on: conversations (the text of conversations on this computer, the agent's reasoning and the names of the tools it used, including the background work of team members, discussions and delegated tasks; what those tools read or wrote and the attachments themselves are left out, while file names that appear in messages and anything the agent repeated from your notes or files in its replies are included; keys in common formats are masked and everything else is uploaded as is), and the activity log (including the first few dozen characters of conversations and the names of note files). Each upload only includes the part of these two that hasn't been uploaded yet, going back at most 7 days.
- The sign-in credentials and API keys saved on this computer, your note files, agent memory and personas, and plugin data are never uploaded.
- The cloud keeps each computer's snapshots from the last 14 days. Turning the feature off stops uploads.

## 0.7.1 — 2026-09-30

- 「设置 → Forsion 云端」新增游戏背包式物品格子，可查看物品数量、品质和详情；已领取的兑换券点击后才展示卡密。
- 支持管理员用 JSON 定义的新物品，确认使用后扣除一件并展示实际效果与动画：获得积分、额度重置卡或恢复额度。需要 Server 2.3.28 或更新版本。
- 新版 Forsion 桌面端可从左下角头像菜单直接打开背包。

- Adds a game-style item grid in Settings → Forsion Cloud → Backpack, with quantities, rarity and details. Voucher keys are only revealed when you choose to view them.
- Supports items defined by administrators in JSON. Confirming use consumes one item and shows its effects and animation: points, reset cards or restored quota. Requires Server 2.3.28 or later.
- Newer Forsion Desktop builds can open the backpack directly from the avatar menu.


## 0.7.0 — 2026-09-29

- 新增公告：Forsion 发布重要通知时，打开桌面端会弹出一张公告卡片；点「知道了」或关掉之后就不再出现。公告里的链接会在浏览器中打开。
- 在「设置 → Forsion 云端 → 额度与积分」里使用额度重置卡后，会播放用卡动画，展示今日与本周额度恢复了多少。需要较新的 Forsion 桌面端；旧版本仍在页面上显示使用前后的对比。
- 「积分自动抵扣」已下线：AI 额度用完后不再自动扣积分继续使用。积分仍然可以兑换额度重置卡。

- Announcements: when Forsion posts an important notice, it pops up as a card when you open the desktop app. Once you choose "Got it" or close it, it doesn't show again. Links in announcements open in your browser.
- Using a quota reset card in Settings → Forsion Cloud → Quota & points now plays the reset card animation, showing how much of today's and this week's quota is back. This needs a newer Forsion Desktop build; older builds keep showing the before-and-after on the page.
- "Pay with points automatically" has been retired: points are no longer spent automatically when your AI quota runs out. You can still use points to get quota reset cards.

## 0.6.0 — 2026-09-29

- 「设备互联」的云端那一半改由本包提供：经 Forsion 云端中转让其他设备连上这台电脑、向设备列表报告这台电脑的状态，以及查看、改名、换图标、移除设备和在浏览器中打开设备。用法和之前一样。
- 服务器重启的那几秒里连不上时，不再清掉这台电脑的配对重新登记，设备列表里不会因此多出一台台离线的重复设备。
- 没装本包的桌面端不再列出账号下的其他设备，也不经云端中转接受连接；同一局域网直连和「允许其他设备连接本机」照常可用。
- 需要较新的 Forsion 桌面端才会启用；旧桌面端上本包照旧提供 0.5 的功能。

- Device connectivity's cloud half now comes from this package: the Forsion cloud relay that lets your other devices reach this computer, reporting this computer's status to your device list, and viewing, renaming, changing the icon of, removing and opening devices in your browser. Everything works as before.
- If the connection drops for a few seconds while the server restarts, this computer keeps its pairing instead of registering again, so your device list no longer fills up with offline duplicates.
- Desktops without this package no longer list the other devices on your account or accept connections through the cloud relay; same-network direct connections and "Allow other devices to connect" keep working.
- This needs a newer Forsion Desktop build; on older desktops this package keeps providing the 0.5 features.

## 0.5.1 — 2026-09-29

- 从桌面端打开账号中心或充值页时，网址里不再带登录令牌，改为一次性交接码：60 秒内有效、只能用一次，不会留在浏览器历史里。需要服务端更新后才生效，在这之前照旧打开。
- 兑换额度重置卡时，如果单价刚好被调整，不会按新价格直接扣积分：页面会提示并显示新价格，请确认后再兑换。
- 用量页的消耗百分比与网页个人中心写法一致（例如 3%，不再写成 3.0%）。
- 附上随包带的第三方开源组件的许可声明。

- Opening the account center or the top-up page from the desktop no longer puts your sign-in token in the address. A one-time handoff code is used instead: it works once, expires after 60 seconds and doesn't stay in your browser history. This takes effect once the server is updated; until then these pages open as before.
- If the reset card price changes while you're exchanging points, you are no longer charged the new price right away: the page tells you, shows the new price and asks you to confirm again.
- Usage percentages are written the same way as on the web account center (for example 3%, not 3.0%).
- Adds the license notices for the open-source components bundled in this package.

## 0.5.0 — 2026-09-29

- 设置里新增「Forsion 云端」，和账号有关的事在桌面端就能办完：
  - 账号：头像、昵称、绑定的手机和邮箱、会员档位与到期日，以及这台电脑上登录过的账号；
  - 额度与积分：今日和本周的 AI 额度、额度重置卡（使用和用积分兑换）、积分余额与充值、后台额度（Muse 与自动化使用）、邀请码和兑换码；
  - 安全：绑定或更换手机和邮箱、修改密码、退出所有设备、注销账号；
  - 用量记录：最近 7、30、90 天的请求次数、成功率和 AI 额度消耗；
  - 反馈：提交问题和建议，并直接在桌面上看到回复。
- AI 额度统一只显示剩余百分比，进度条按剩余填充；额度为 0 时显示 0%，不再误显示成「不限」。
- 改密码的规则与服务端一致并写在界面上；只绑定了邮箱也能用验证码改密码，也可以直接用当前密码修改。
- 充值积分会直接打开充值页；已下线的周重置卡不再出现。
- 需要较新的 Forsion 桌面端，这些页面才会出现；旧桌面端上本包不显示它们，账号设置照旧用桌面端自带的那一页。

- Settings now has a Forsion Cloud section, so you can take care of your account without leaving the desktop app:
  - Account: your photo, nickname, linked phone and email, membership tier and expiry date, and the accounts you've signed in with on this computer;
  - Quota & points: today's and this week's AI quota, quota reset cards (use one or exchange points for more), your points balance and top-ups, the background quota used by Muse and automations, invite codes and redemption codes;
  - Security: link or change your phone and email, change your password, sign out everywhere, delete your account;
  - Usage: requests, success rate and AI quota used over the last 7, 30 or 90 days;
  - Feedback: send issues and suggestions, and read replies right in the app.
- AI quota is always shown as the percentage left, and the bars show what remains; a quota of 0 now reads 0% instead of Unlimited.
- Password rules match the server and are listed on screen. You can change your password with a verification code even if you only linked an email, or directly with your current password.
- Buying points opens the points page directly, and the retired weekly reset card no longer appears.
- These pages need a newer Forsion Desktop build. On older desktops this package doesn't show them, and account settings stay on the page the desktop already has.

## 0.4.0 — 2026-09-28

- 笔记的云端同步与协作从 Forsion 本体搬入本包:云端笔记库镜像、按条目同步、与我共享、页面分享 / 发布 / 在线成员,行为与之前一致。没装本包的桌面端不再显示云端笔记库、云同步与分享入口。
- 需要较新的 Forsion 桌面端才会启用;旧桌面端上本包只提供 0.3 的功能,不影响使用。

Cloud sync and collaboration for notes now ship in this package, moved over from Forsion itself with their behavior unchanged: the cloud vault mirror, per-item sync, shared-with-me, page sharing / publishing / presence. Desktops without this package no longer show the cloud vault, cloud sync or sharing entry points.
This needs a newer Forsion Desktop build; on older desktops this package keeps providing the 0.3 features and nothing else changes.

## 0.3.0 — 2026-09-28

- 账号登录态从 Forsion 本体搬入本包:登录、登出、切换账号、账号状态与登录态自动续期都由本包提供,行为与之前一致。没装本包的桌面端不再显示账号卡、Forsion 设置页与登录入口。
- 「设置 → 同步 → 本地库远程同步」里的「Forsion 云端」后端也搬入本包;没装本包的桌面端不再列出这一项。
- 需要较新的 Forsion 桌面端才会启用以上两块;旧桌面端上本包只提供 0.2 的功能,不影响使用。

Account sign-in now ships in this package, moved over from Forsion itself with its behavior unchanged: signing in, signing out, switching accounts, account status and keeping you signed in. Desktops without this package no longer show the account card, the Forsion settings page or the sign-in entry points.
The "Forsion cloud" backend under Settings → Sync → Remote sync of the local vault ships here too; desktops without this package no longer list it.
Both need a newer Forsion Desktop build; on older desktops this package keeps providing the 0.2 features and nothing else changes.

## 0.2.0 — 2026-09-27

- Forsion Connect(Coding Space 项目发布、应用商店上架申请、预览态 AI 代理)从 Forsion 本体搬入本包,行为与之前一致。预览页里的 `window.forsion`(`/forsion-connect.js`)与 `/__forsion/*` 云端代理也随之由本包提供。
- 需要较新的 Forsion 桌面端才会启用 Connect;旧桌面端上本包只提供云端账号功能,不影响使用。

Forsion Connect (Coding Space project publishing, app store listing requests, and the preview-mode AI proxy) now ships in this package, moved over from Forsion itself with its behavior unchanged. The `window.forsion` SDK served to preview pages (`/forsion-connect.js`) and the `/__forsion/*` cloud proxy come from this package as well.
Connect is enabled on newer Forsion Desktop builds only; on older desktops this package keeps providing the cloud-account features and nothing else changes.

## 0.1.0 — 2026-09-27

- 首个版本。Forsion 云端账号相关的桌面功能首次从 Forsion 本体搬出,作为内置插件随桌面端发布、自动更新:个人中心与会员页入口、额度视图与重置卡、后台额度转换,以及反馈中心提交。
- 插件以当前账号身份调用 Forsion 云端 API 的通用接口(`cloud:fetch`)也在这个包里,行为与之前一致。

First release. The cloud-account features of Forsion Desktop now ship as a built-in plugin that updates on its own: the account center and membership page shortcuts, the quota view and reset cards, background quota conversion, and feedback submission. The shared interface plugins use to call the Forsion cloud API as the signed-in account (`cloud:fetch`) is part of this package too, unchanged in behavior.
